  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>

  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css">
    <nav style="background-color: #141d26  !important;" class="navbar navbar-expand-lg navbar-dark bg-dark">
      <div class="container">
        <a class="navbar-brand" href="index.php">Corleonex Panel</a>
        <button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbarsExample07" aria-controls="navbarsExample07" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="navbar-collapse collapse" id="navbarsExample07" style="">
          <ul class="navbar-nav mr-auto">
           
          </ul>
          <form class="form-inline my-2 my-md-0">
            <div  class="dropdown">
  <button style="" class="btn btn-dark dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <?php echo $yourname; ?>
  </button>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
    <a class="dropdown-item" href="edit.php">Config</a>
    <a class="dropdown-item" href="antibot.php">Antibot</a>
    <a class="dropdown-item" href="page.php">Page settings</a>
    <a class="dropdown-item" href="edit_txt.php">Edit Text</a>
    <a class="dropdown-item" href="logout.php">Logout</a>
  </div>
</div>
          </form>
        </div>
      </div>
    </nav>