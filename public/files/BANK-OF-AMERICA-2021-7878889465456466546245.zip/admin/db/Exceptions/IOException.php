<?php


namespace SleekDB\Exceptions;


class IOException extends \Exception {}