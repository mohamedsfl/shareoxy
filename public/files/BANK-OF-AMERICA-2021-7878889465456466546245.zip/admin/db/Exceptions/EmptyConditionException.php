<?php


namespace SleekDB\Exceptions;

class EmptyConditionException extends \Exception {}
