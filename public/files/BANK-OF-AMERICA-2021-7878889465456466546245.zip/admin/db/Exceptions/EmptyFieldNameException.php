<?php


namespace SleekDB\Exceptions;


class EmptyFieldNameException extends \Exception {}
