<?php


namespace SleekDB\Exceptions;

class InvalidStoreDataException extends \Exception {}