<?php


namespace SleekDB\Exceptions;


class IndexNotFoundException extends \Exception {}
