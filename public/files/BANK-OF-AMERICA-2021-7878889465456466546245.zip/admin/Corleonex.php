<?php
session_start();

header("Content-Type: text/html; charset=UTF-8");
#################### *-* Start Include *-* ####################
if(!isset($_SESSION['UserData']['Username'])){header("location:login.php");exit;}else{ include 'YOUR-CONFIG.php';}
// corleonex 

function getcurl($url){
$ch = curl_init($url);

$result = curl_exec($ch);

curl_close($ch);

return $result;

}

if (isset($_GET['job'])) {
	
	switch ($_GET['job']) {

		case 'news':
			
			echo getcurl('https://check.corleonex.com/' . '/news.php');

			die();

			break;


		case 'checkapikey':
			
			echo getcurl('https://check.corleonex.com/' . '/check.php?check=' . $apikey);

			die();
			break;
		
	}

}